public enum AttackSpeedType
{
    Slow,
    RelativelySlow,
    Medium,
    Fast,
    VeryFast
}
