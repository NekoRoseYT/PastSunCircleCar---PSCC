
public enum OperatorDeployOrientationType
{
    None,
    Left,
    Up,
    Right,
    Down
}
