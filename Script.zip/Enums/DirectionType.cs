public enum DirectionType
{
    Up,
    Left,
    Down,
    Right
}
