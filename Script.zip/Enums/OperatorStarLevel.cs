using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum OperatorStarLevel 
{
    ThreeStars,
    FourStars,
    FiveStars,
    SixStars
}
