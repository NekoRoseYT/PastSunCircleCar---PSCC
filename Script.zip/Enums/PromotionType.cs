using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PromotionType 
{
    Zero,
    One,
    Two
}
