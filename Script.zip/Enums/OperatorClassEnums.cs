

public enum OperatorDeployType 
{
    None,
    Ground,
    HighGround,
    Hybrid
}

public enum GroundOperatorClass
{
    Vanguards,
    Defender,
    Guard

}
public enum HighGroundOperatorClass
{
    Sniper,
    Suppurter,
    Healing
}