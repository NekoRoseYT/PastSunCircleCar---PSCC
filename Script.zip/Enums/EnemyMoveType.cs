public enum EnemyMoveType
{
    None,
    Ground,
    Fight
}
