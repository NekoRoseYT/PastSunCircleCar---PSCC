public enum ItemType
{
    BaseExp,
    EarlyExp,
    MediumExp,
    HightClassExp,
    LongMenBi
}
