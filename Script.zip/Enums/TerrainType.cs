public enum TerrainType
{
    NoEntry,
    Passable,
    Trap,
    EscapePoint
}
