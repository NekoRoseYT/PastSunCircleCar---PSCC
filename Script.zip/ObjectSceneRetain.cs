using UnityEngine;

public class ObjectSceneRetain : MonoBehaviour
{
    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
}
