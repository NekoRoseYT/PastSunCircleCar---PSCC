using UnityEngine;

public interface IUIPanel
{
    void ShowUi();
    void HideUi();
    void SetPreviousPanel(GameObject panel);
    GameObject GetPreviousPanel();
    GameObject GetObject();
}
