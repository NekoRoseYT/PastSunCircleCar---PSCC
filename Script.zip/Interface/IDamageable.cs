
public interface IDamageable 
{
    public bool canByDamage{get;}
    public bool canByCure{get;}
    public Terrain GetCurrentTerrain();
    public bool IsMayCure();
    public void TakeHealt(Stats_OffenseGroup offenseGroup);
    public bool TakeDamage(Stats_OffenseGroup offenseGroup);
    public void Die();
}
