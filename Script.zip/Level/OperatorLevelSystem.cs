using System;
using UnityEngine;

public class OperatorLevelSystem
{
    public int maxLevel;
    public int presentLevel = 1;

    public PromotionType promotion = PromotionType.Zero;

    public const int PROMOTION_MAXLEVEL_ZERO = 50;
    public const int PROMOTION_MAXLEVEL_ONE = 70;
    public const int PROMOTION_MAXLEVEL_TWO = 90;

    public const int PROMOTION_EXP_CURVE_ZERO = 17;
    public const int PROMOTION_EXP_CURVE_ONE = 52;
    public const int PROMOTION_EXP_CURVE_TWO = 156;

    public const int PROMOTION_ZERO_INITIAL_EXP = 100;
    public const int PROMOTION_ONE_INTIAL_EXP = 120;
    public const int PROMOTION_TWO_INTIAL_EXP = 191;

    public int presentExp = 1;
    public int maxExp = 1;
    public int overflowExp = 1;

    public OperatorLevelSystem()
    {
        LevelSystemInitialze();
    }
    public void LevelSystemInitialze()
    {
        PromotionMaxLevel();
        PromotionInitialExp();
        MaxExpInitialize();
    }
    public void MaxExpInitialize()
    {
        int promotionMaxExp = PromotionDecide();
        
        for(int i = 0; i < presentLevel; i++)
        {
            maxExp += promotionMaxExp;
        }
    }
    /// <summary>
    /// ��Ӣ����
    /// </summary>
    public void PromotionUP()
    {
        switch (promotion)
        {
            case PromotionType.Zero:
                promotion = PromotionType.One;
                break;
            case PromotionType.One:
                promotion = PromotionType.Two;
                break;
        }
        PromotionInitialExp();
    }
    /// <summary>
    /// �ȼ�����
    /// </summary>
    public void Upgrade()
    {
        presentLevel++;
    }
    /// <summary>
    /// ���뾭��
    /// </summary>
    /// <param itemName="exp"></param>
    public void SetExp(int exp)
    {
        if (presentLevel >= maxLevel)
            return;
        presentExp += exp;
        if (presentExp >= maxExp)
        {
            overflowExp = presentExp - maxExp;
            Upgrade();

        }
    }

    /// <summary>
    /// ���ݾ�Ӣ�׶����������ۼӾ���ֵ
    /// ���������������辭�飬��Ӣ��ÿ���׶����Է��ȶ���һ�£�����������ݾ�Ӣ�׶η�����Ӧ��������������
    /// </summary>
    /// <returns>��ǰ�׶�ÿ���ۼӾ���ֵ</returns>
    public int PromotionDecide()
    {
        switch (promotion)
        {
            case PromotionType.Zero:
                return PROMOTION_EXP_CURVE_ZERO;

            case PromotionType.One:
                return PROMOTION_EXP_CURVE_ONE;
            case PromotionType.Two:
                return PROMOTION_EXP_CURVE_TWO;
        }
        Debug.LogError("��Ա��Ӣö�ٴ�������");
        return 0;

    }
    /// <summary>
    /// ���ݾ�Ӣ�׶��������ȼ�
    /// </summary>
    private void PromotionMaxLevel()
    {
        switch (promotion)
        {
            case PromotionType.Zero:
                maxLevel = PROMOTION_MAXLEVEL_ZERO;
                break;
            case PromotionType.One:
                maxLevel = PROMOTION_EXP_CURVE_ONE;
                break;
            case PromotionType.Two:
                maxLevel = PROMOTION_EXP_CURVE_TWO;
                break;
        }
    }
    private void PromotionInitialExp()
    {
        switch (promotion)
        {
            case PromotionType.Zero:
                maxExp = PROMOTION_ZERO_INITIAL_EXP;
                break;
            case PromotionType.One:
                maxExp = PROMOTION_ONE_INTIAL_EXP;
                break;
            case PromotionType.Two:
                maxExp = PROMOTION_TWO_INTIAL_EXP;
                break;
        }
    }
}

