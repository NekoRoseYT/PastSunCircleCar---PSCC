using UnityEngine;

public class LevelUpManager : MonoBehaviour
{
    public static LevelUpManager Instance;

    private PlayOperatorData operatorData {get => GetComponent<IDataUser<PlayOperatorData>>().GetData();}
    private UpgradePreviewData upgradeData;
    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    public bool LevelUp()
    {
        if (upgradeData.targetLevel <= operatorData.configSo.levelSystem.presentLevel || !upgradeData.resourceCheckResult)
        {
            Debug.LogWarning("����ʧ��_" + operatorData.configSo.name + upgradeData.resourceCheckResult + upgradeData.targetLevel);
            return false;
        }
        operatorData.configSo.levelSystem.presentLevel = upgradeData.targetLevel;
        operatorData.configSo.levelSystem.presentExp = 0;
        operatorData.configSo.levelSystem.maxExp = upgradeData.levelUpResidueMaxExp;

        operatorData.configSo.stats.healthGroup.maxHealth = upgradeData.upgradeStats.health;
        operatorData.configSo.stats.offenseGroup.physicalDamage = upgradeData.upgradeStats.damage;
        operatorData.configSo.stats.defenseGroup.physicalDefense = upgradeData.upgradeStats.defense;
        operatorData.configSo.stats.defenseGroup.spellResistance = upgradeData.upgradeStats.spellResistance;
        return true;
    }
    /// <summary>
    /// �Ʋ�����������Դ
    /// </summary>
    /// <param itemName="upLevel">Ŀ��ȼ�</param>
    /// <returns>����������Դ</returns>
    public UpgradePreviewData CalculatePreviewData(int upLevel)
    {
        //upLevel -= operatorData.configSo.levelSystem.presentLevel;
        upgradeData = new UpgradePreviewData();
        OperatorLevelSystem levelSystem = operatorData.configSo.levelSystem;
        upgradeData.targetLevel = upLevel;

        PreviewExpCalculate(upLevel, ref upgradeData, operatorData.configSo.levelSystem);
        PreviewStatsCalculate(upLevel, ref upgradeData, operatorData);

        //upgradeData.targetLevel = upLevel += operatorData.configSo.levelSystem.presentLevel; //Ŀ��ȼ�

        upgradeData.resourceCheckResult = CanLevelUp();

        return upgradeData;
    }
    /// <summary>
    /// �Ʋ��������辭��
    /// </summary>
    /// <param itemName="upLevel">Ŀ��ȼ�</param>
    /// <param itemName="previewData">Ԥ�������洢��</param>
    /// <param itemName="levelSystem">�ȼ�ϵͳ����������</param>
    private void PreviewExpCalculate(int upLevel, ref UpgradePreviewData previewData, OperatorLevelSystem levelSystem)
    {
        int previeRequriedExp = levelSystem.maxExp - levelSystem.presentExp;
        //int previewMaxExp = levelSystem.maxExp;
        int previewMaxExp = levelSystem.maxExp;
        //previewMaxExp += levelSystem.PromotionDecide();
        
        for (int i = levelSystem.presentLevel; i < upLevel; i++)
        {
            //previeRequriedExp += previewMaxExp;
            //previewMaxExp += levelSystem.PromotionDecide();
            previeRequriedExp += previewMaxExp;
            previewMaxExp += levelSystem.PromotionDecide();
        }
        previewData.expRequried = previeRequriedExp;
        //previewData.levelUpResidueMaxExp = previewMaxExp;
        previewData.levelUpResidueMaxExp = previewMaxExp;
        previewData.levelUpResidueExp = 0;

        
    }
    /// <summary>
    /// Ԥ�����ԣ����㷽��
    /// </summary>
    /// <param itemName="upLevel">Ŀ��ȼ�</param>
    /// <param itemName="previewData">������</param>
    /// <param itemName="operatorData">��Ա������Ϣ</param>
    private void PreviewStatsCalculate(int upLevel, ref UpgradePreviewData previewData, PlayOperatorData operatorData)
    {
        StatsData stats = operatorData.stats;
        PropertyGrowthSO propertyGrowth = operatorData.configSo.statsGrowth;
        OperatorLevelSystem levelSystem = operatorData.configSo.levelSystem;

        UpgradeStats upgradeStats = new UpgradeStats();
        upgradeStats.health = (int)stats.healthGroup.maxHealth;
        upgradeStats.damage = (int)stats.offenseGroup.physicalDamage;
        upgradeStats.defense = (int)stats.defenseGroup.physicalDefense;
        upgradeStats.spellResistance = (int)stats.defenseGroup.spellResistance;

        for (int i = levelSystem.presentLevel; i < upLevel; i++)
        {
            upgradeStats.health += (int)(upgradeStats.health / 100 * propertyGrowth.healthGrowth);
            upgradeStats.damage += (int)(upgradeStats.damage / 100 * propertyGrowth.damageGrowth);
            upgradeStats.defense += (int)(upgradeStats.defense / 100 * propertyGrowth.defenseGrowth);
            upgradeStats.spellResistance += (int)(upgradeStats.spellResistance / 100 * propertyGrowth.spellResistanceGrowth);
        }
        previewData.upgradeStats = upgradeStats;
    }
    private bool CanLevelUp()
    {
        return true;
    }

}

public struct UpgradePreviewData
{
    public int targetLevel;//Ŀ��ȼ�
    public int expRequried;//���辭��
    public int levelUpResidueExp;//�������ʣ�ྭ��ֵ
    public int levelUpResidueMaxExp;
    public int lmbRequried;//�������ű�
    public UpgradeStats upgradeStats;//��������
    public bool resourceCheckResult;//��Դ�Ƿ��㹻����
}
public struct UpgradeStats
{
    public int health;
    public int damage;
    public int defense;
    public int spellResistance;
}