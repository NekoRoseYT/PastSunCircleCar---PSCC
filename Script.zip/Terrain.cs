using UnityEngine;

public class Terrain : MonoBehaviour
{
    public TerrainDataSO terrainData;

    private Vector2Int currentPosition;

    public Operator deployOperator;
    public bool currentWalkable;
    private void Awake()
    {
        currentWalkable = terrainData.walkable;
    }

    public void SetCurrentPosition(int x,int y)
    {
        currentPosition = new Vector2Int(x, y);
    }
    public Vector2Int GetCurrentPosition()
    {
        return currentPosition;
    }
    public virtual void TerrainFunction(Entity entity)
    {

    }
}
