public static class GamePlayTool
{
    /// <summary>
    /// ��յз�Ŀ��ķ���
    /// </summary>
    /// <param name="enemyData">Ҫ��յĵз�</param>
    public static void EnemyTargetClear(Enemy enemyData)
    {
        if(enemyData.planTargets.Contains(enemyData.targetOperator))
            enemyData.planTargets.Remove(enemyData.targetOperator);
        enemyData.targetOperator = null;
        enemyData.targetTerrain = null;
    }
}
