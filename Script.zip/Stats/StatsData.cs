using System;

[Serializable]
public class StatsData
{
    public Stats_HealthGroup healthGroup = new Stats_HealthGroup();
    public Stats_OffenseGroup offenseGroup = new Stats_OffenseGroup();
    public Stats_DefenseGroup defenseGroup = new Stats_DefenseGroup();
}
