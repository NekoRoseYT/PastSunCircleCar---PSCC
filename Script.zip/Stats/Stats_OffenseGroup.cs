using System;
using UnityEngine;

[Serializable]
public class Stats_OffenseGroup
{
    [Header("�����˺�")]
    public float physicalDamage;
    public float spellDamage;

    [Header("Ԫ������")]
    public float burnDamage;
    public float frostDamage;
    public float apoptosisDamage;
    public float neuroDamage;
    public float erosionDamage;
}
