using System;

[Serializable]
public class Stats_HealthGroup
{
    public float maxHealth;
}
