
using System.Collections.Generic;

public class EntityMayAttackArchitecture : CombatEntity,IDamageable
{
    public bool canByCure{get;protected set;}
    public bool canByDamage{get;protected set;} = true;
    private Entity_Damage damage;

    protected virtual void Awake()
    {
        damage = GetComponent<Entity_Damage>();
        currentHealth = stats.healthGroup.maxHealth;
        damage.Die += Die;
    }
    protected virtual void Start()
    {
        currentTerrain = TerrainManage.Instance.WordToTerrainsPosition(transform.position);
        PlayerDataManage.Instance.AddGridEnemy(this);
    }
    public bool TakeDamage(Stats_OffenseGroup offenseGroup)
    {
        if(damage == null)
            return false;
        damage.TakeDamage(offenseGroup);
        return true;
    }
    public void TakeHealt(Stats_OffenseGroup offenseGroup)
    {
        currentHealth += offenseGroup.physicalDamage;
    }
    // public virtual
    public virtual void Die()
    {
        damage.Die -= Die;
        PlayerDataManage.Instance.gridEnemys[currentTerrain].Remove(this);
        gameObject.SetActive(false);
    }
    public Terrain GetCurrentTerrain()
    {
        return currentTerrain;
    }

    public bool IsMayCure()
    {
        return false;
    }
}
