using Spine.Unity;
using UnityEngine;

public class Entity : CombatEntity,IDamageable
{
    public bool canByDamage{get;protected set;}
    public bool canByCure{get;protected set;}
    public SkeletonAnimation spineAnimation;
    protected StateMachine machine;
    protected Entity_Damage damage;
    protected Entity_DieState dieState;
    protected virtual void Awake()
    {
        spineAnimation = GetComponentInChildren<SkeletonAnimation>();
        machine = new StateMachine();

        damage = gameObject?.GetComponent<Entity_Damage>();
        if(damage==null)
            canByDamage = false;
        else
        {
            canByDamage = true;
            damage.Die += Die;
        }
        dieState = new Entity_DieState(this,machine,"Die");   
        InitializeState();
    }
    protected virtual void OnEnable()
    {
    }
    // Start is called before the first frame update
    protected virtual void Start()
    {
        currentHealth = maxHealth;
    }

    // Update is called once per frame
    protected virtual void Update()
    {
        machine.UpdataMachine();
    }
    protected virtual void InitializeState()
    {
    }
    public bool IsCanDamage()
    {
        return damage != null;
    }
    public Terrain GetCurrentTerrain()
    {
        return currentTerrain;
    }
    public bool TakeDamage(Stats_OffenseGroup offenseGroup)
    {
        if(damage == null)
            return false;
        damage.TakeDamage(offenseGroup);
        return true;
    }
    public virtual void TakeHealt(Stats_OffenseGroup offenseGroup)
    {
    }
    // public virtual
    public virtual void Die()
    {
        if(damage != null)
            damage.Die -= Die;
        machine.CutState(dieState);
    }
    public Entity_State GetCurrentState()
    {
        return machine.currentState;
    }

    public virtual bool IsMayCure()
    {
        return false;
    }
}
