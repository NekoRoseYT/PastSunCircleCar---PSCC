using System;
using UnityEngine;

[Serializable]
public class Entity_Stats
{
    public StatsData stats;

    /// <summary>
    /// ��ȡ�����˺�ֵ
    /// </summary>
    /// <returns></returns>
    public float GetPhysicalDamage()
    {
        float baseDamage = stats.offenseGroup.physicalDamage;
        float baseDefense = stats.defenseGroup.physicalDefense;
        float calculateDamage = baseDamage - baseDefense;

        float finalDamage = Mathf.Clamp(calculateDamage, 0, calculateDamage);

        return finalDamage;
    }
    /// <summary>
    /// ��ȡ�����˺�ֵ
    /// </summary>
    /// <returns></returns>
    public float GetSpellDamage()
    {
        float baseDamage = stats.offenseGroup.spellDamage;
        float baseResistance = stats.defenseGroup.spellResistance;
        float calculateDamage = baseDamage - baseResistance;

        float finalDamage = Mathf.Clamp(calculateDamage, 0, calculateDamage);

        return finalDamage;
    }

}
