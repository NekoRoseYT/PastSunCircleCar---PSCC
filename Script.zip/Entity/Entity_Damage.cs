using System;
using UnityEngine;

public class Entity_Damage : MonoBehaviour
{
    private static float k = 100f;
    public event Action Die;
    public event Action HealtUpdata;
    private CombatEntity combatEntity;
    private StatsData stats;
    private void Awake()
    {
        combatEntity = GetComponent<CombatEntity>();
    }
    void Start()
    {
        stats = combatEntity.stats;
    }

    protected virtual void CheckHealth()
    {
        if (combatEntity.currentHealth <= 0)
        {
            Die?.Invoke();
        }else
        {
            HealtUpdata?.Invoke();
        }
    }
    protected virtual float PhysicsDamage(float damage)
    {
        float defense = stats.defenseGroup.physicalDefense;
        float reduction = defense / (defense + k);
        float finalDamage = damage * (1 - reduction);

        return finalDamage;
    }
    protected virtual float SpellDamage(float damage)
    {
        return Mathf.Max(damage - stats.defenseGroup.spellResistance ,0);
    }
    public void TakeDamage(Stats_OffenseGroup offenseGroup)
    {
        combatEntity.currentHealth -= PhysicsDamage(offenseGroup.physicalDamage);
        combatEntity.currentHealth -= SpellDamage(offenseGroup.spellDamage);
        CheckHealth();
    }
    public void TakeHealt(Stats_OffenseGroup offenseGroup,ref float currentHealth)
    {
        currentHealth = Mathf.Min((currentHealth + offenseGroup.physicalDamage),stats.healthGroup.maxHealth);  
        CheckHealth();
    }
}
