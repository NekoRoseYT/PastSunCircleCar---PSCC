using UnityEngine;

public class CombatEntity : MonoBehaviour
{
    public Terrain currentTerrain;
    public StatsData stats;
    public float maxHealth{get => stats.healthGroup.maxHealth;}
    public float currentHealth;

}
