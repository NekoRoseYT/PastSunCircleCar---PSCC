using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_ItemData : MonoBehaviour
{
    public ItemDataSO dataSo;
    public long quantity { private set; get; } = 0;

    
    public void Add() => quantity++;
    public void Add(long quantity) => this.quantity += quantity;

    public void Reduce() => quantity--;
    public void Reduce(long quantity) => this.quantity += quantity;
}
