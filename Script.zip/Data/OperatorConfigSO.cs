using System;
using System.IO;
using UnityEngine;
[Serializable]
[CreateAssetMenu(menuName = "��Ա/��Ա����", fileName = "��Ա����")]
public class OperatorConfigSO : ScriptableObject
{
    public int operatorId;
    public string operatorName;
    public bool canByCure = true;
    public int cost;
    public int grade;
    public int deployTime;//�ٲ���ʱ��
    public float attackSpeed;//����
    public int attackNumber;//��������
    [Header("������Χ")]
    public GameObject attackRange_Ui;
    public OperatorAttackRangeType rangeType;
    [Header("ͼƬ���")]
    private Sprite _fullIllustration;
    public Sprite fullIllustration
    {
        get
        {
            if (_fullIllustration == null)
            {
                _fullIllustration = operatorTexture.fullIllustration;
                if (_fullIllustration == null)
                    Debug.LogError("δ���ҵ�" + operatorName + "��ͼ");
            }
            return _fullIllustration;
        }
    }
    private Sprite _headPortrait;
    public Sprite headPortrait
    {
        get
        {
            if (_headPortrait == null)
            {
                _headPortrait = operatorTexture.headPortrait;
                if (_headPortrait == null)
                    Debug.LogError("δ���ҵ�" + operatorName + "ͷ��");
            }
            return _headPortrait;
        }
    }
    private Sprite _deployIcon;
    public Sprite deployIcon
    {
        get
        {
            if (_deployIcon == null)
            {
                _deployIcon = operatorTexture.deployIcon;
                if (_deployIcon == null)
                    Debug.LogError("δ���ҵ�" + operatorName + "����ͷ��");
            }
            return _deployIcon;
        }
    }
    private OperatorTextureConfigSO _operatorTexture;
    private OperatorTextureConfigSO operatorTexture
    {
        get
        {
            if (_operatorTexture == null)
            {
                _operatorTexture = Resources.Load<OperatorTextureConfigSO>(Path.Combine( "Operators","OperatorImages","��ԱTexture_" + operatorId));
                if(_operatorTexture == null)
                {
                    Debug.LogError("δ���ҵ���ӦTextureSO��Դ_" + operatorId);
                }
            }
            return _operatorTexture;
        }
    }
    //public ImageTransformData imageTransform;
    [Header("��������")]
    public int resist;
    public PropertyGrowthSO statsGrowth;
    public StatsData stats;
    public OperatorLevelSystem levelSystem = new OperatorLevelSystem();
    public OperatorDeployTimeType deployTimeType;
    public AttackSpeedType attackSpeedType;

    [Header("ְҵ����")]
    public Sprite professionIcon;
    public OperatorStarLevel StarLevel;

    public OperatorDeployType deployType;



    private void Awake()
    {
        DeployTimeInitialize();
        AttackSpeedInitialize();
    }

    private void DeployTimeInitialize()
    {
        switch (deployTimeType)
        {
            case OperatorDeployTimeType.VerySlow:
                deployTime = 55;
                break;
            case OperatorDeployTimeType.Slow:
                deployTime = 45;
                break;
            case OperatorDeployTimeType.Medium:
                deployTime = 35;
                break;
            case OperatorDeployTimeType.Fast:
                deployTime = 25;
                break;
            case OperatorDeployTimeType.VeryFast:
                deployTime = 10;
                break;
        }

    }
    private void AttackSpeedInitialize()
    {
        switch (attackSpeedType)
        {
            case AttackSpeedType.Slow:
                attackSpeed = 0.6f;
                break;
            case AttackSpeedType.RelativelySlow:
                attackSpeed = 0.8f;
                break;
            case AttackSpeedType.Medium:
                attackSpeed = 1f;
                break;
            case AttackSpeedType.Fast:
                attackSpeed = 1.2f;
                break;
            case AttackSpeedType.VeryFast:
                attackSpeed = 1.3f;
                break;
        }
    }
}