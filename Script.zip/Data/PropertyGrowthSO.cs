using System;

[Serializable]
public class PropertyGrowthSO
{
    public float healthGrowth = 1f;
    public float damageGrowth = 1f;
    public float defenseGrowth = 1f;
    public float spellResistanceGrowth = 1f;

}
