using System;
using UnityEngine;

[Serializable]
[CreateAssetMenu(menuName = "�з�/�з�����",fileName = "�з�����")]
public class EnemyConfigSO : ScriptableObject
{
    public int enemyId;
    public string enemyName;
    public float attackSpeed;
    public AttackSpeedType attackSpeedType;

    public StatsData stats;

    private void Awake()
    {
        AttackSpeedInitialize();
    }

     private void AttackSpeedInitialize()
    {
        switch (attackSpeedType)
        {
            case AttackSpeedType.Slow:
                attackSpeed = 0.6f;
                break;
            case AttackSpeedType.RelativelySlow:
                attackSpeed = 0.8f;
                break;
            case AttackSpeedType.Medium:
                attackSpeed = 1f;
                break;
            case AttackSpeedType.Fast:
                attackSpeed = 1.2f;
                break;
            case AttackSpeedType.VeryFast:
                attackSpeed = 1.3f;
                break;
        }
    }
}
