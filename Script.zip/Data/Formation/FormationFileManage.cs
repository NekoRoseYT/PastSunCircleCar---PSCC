using System.Collections.Generic;
using System.IO;
using UnityEngine;

public static class FormationFileManage
{
    private static string _SavePath;
    private static string SavePath
    {
        get
        {
            if (string.IsNullOrEmpty(_SavePath))
            {
                _SavePath = Path.Combine(Application.persistentDataPath, "Formation.json");//Combine�ϲ�·����֤��ƽ̨������
            }
            return _SavePath;
        }
    }
    private static List<int> ids;//���ش洢ID����
    static FormationFileManage()
    {
        Load();
    }

    public static List<PlayOperatorData> Load()
    {
        if (!File.Exists(SavePath))
        {
            Debug.Log("����ļ�������");
            return null;
        }
        List<PlayOperatorData> operatorDatas = new List<PlayOperatorData>(FormationManage._maxCapacity);
        string json = File.ReadAllText(SavePath);

        ids = JsonUtility.FromJson<FormationIds>(json).ids;

        //����id�����Ҷ�Ӧ��Ա��
        foreach (int id in ids)
        {
            PlayOperatorData data = OperatorGroup.Instance.GetOperator(id);
            operatorDatas.Add(data);
        }

        return operatorDatas;
    }
    public static void Save(List<PlayOperatorData> formation)
    {
        FormationIds fids = new FormationIds();
        ids.Clear();
        foreach (PlayOperatorData data in formation)
        {
            ids.Add(data.id);
        }
        fids.ids = ids;
        string json = JsonUtility.ToJson(fids);
        File.WriteAllText(SavePath, json);
    }
}
class FormationIds
{
    public List<int> ids;
}
