using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(menuName = "����", fileName = "��������")]
public class TerrainDataSO : ScriptableObject
{
    // public TerrainType type;

    public string terrainName;
    public Image chartlet;

    public EnemyMoveType moveType;
    public float specialG;
    public bool walkable;
    public float g;
}
