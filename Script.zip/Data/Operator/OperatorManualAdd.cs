using UnityEngine;

public class OperatorManualAdd : MonoBehaviour
{
    public int id;

    [ContextMenu("����������Ӹ�Ա����")]
    private void OperatorManualAddRun()
    {
        //OperatorFileManage.LoadData();
        OperatorGroup group = OperatorGroup.Instance;
        group.Initialize();
        group.AddOperator(new PlayOperatorData(id));
        //OperatorFileManage.AddData(id);
        OperatorFileManage.SaveData(group);
    }
}
