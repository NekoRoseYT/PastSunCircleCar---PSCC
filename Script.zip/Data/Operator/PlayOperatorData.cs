using System;
using System.IO;
using UnityEngine;

[Serializable]
public class PlayOperatorData
{
    public int id;
    public int level;
    public int exp;
    public PromotionType promotion; //��Ӣ���׶�

    public StatsData stats = new StatsData(); //������

    [NonSerialized]
    private OperatorConfigSO _configSo;

    public OperatorConfigSO configSo
    {
        get
        {
            return ConfigSoSetUp();
        }
    }
    public PlayOperatorData() { }
    public PlayOperatorData(int id)
    {
        Initialize(id);
    }
    /// <summary>
    /// ���һ�δ���ʱ���õĳ�ʼ���������������ID������ӦSO�ļ���
    /// ������SO�ļ���ʼ����Ա���ԡ�����
    /// </summary>
    /// <param itemName="id">��Աid</param> 
    public bool Initialize(int id)
    {
        this.id = id;

        OperatorConfigSO so = ConfigSoSetUp();

        if ((so == null))
        {
            Debug.LogError("δ���ҵ�" + id + "�ĸ�Ա");
            return false;
        }
        SaveOperatorData();
        return true;
    }
    public void LoadOperatorData()
    {
        ConfigSoSetUp();
        LevelSystemInitial();
        StatsToLoad();
    }
    public void SaveOperatorData()
    {
        level = _configSo.levelSystem.presentLevel;
        exp = _configSo.levelSystem.presentExp;
        promotion = _configSo.levelSystem.promotion;

        StatsToSave();
    }
    private void LevelSystemInitial()
    {
        _configSo.levelSystem.presentLevel = level;
        _configSo.levelSystem.presentExp = exp;
        _configSo.levelSystem.promotion = promotion;
    }

    public OperatorConfigSO ConfigSoSetUp()
    {
        if (_configSo == null)
        {
            _configSo = Resources.Load<OperatorConfigSO>(Path.Combine( "Operators","Operator_" + id.ToString()));
            if (_configSo == null)
                Debug.LogError("_configSo Ϊnull δ���ҵ���ӦID�ĸ�ԱSO��Դ");
        }
        return _configSo;
    }
    /// <summary>
    /// ��Ա���������Դ洢����
    /// </summary>
    private void StatsToSave()
    {
        stats.healthGroup.maxHealth = configSo.stats.healthGroup.maxHealth;

        stats.offenseGroup.physicalDamage = configSo.stats.offenseGroup.physicalDamage;
        stats.offenseGroup.spellDamage = configSo.stats.offenseGroup.spellDamage;
        stats.offenseGroup.apoptosisDamage = configSo.stats.offenseGroup.apoptosisDamage;
        stats.offenseGroup.erosionDamage = configSo.stats.offenseGroup.erosionDamage;
        stats.offenseGroup.frostDamage = configSo.stats.offenseGroup.frostDamage;
        stats.offenseGroup.burnDamage = configSo.stats.offenseGroup.burnDamage;

        stats.defenseGroup.physicalDefense = configSo.stats.defenseGroup.physicalDefense;
        stats.defenseGroup.spellResistance = configSo.stats.defenseGroup.spellResistance;
        stats.defenseGroup.apoptosisResistance = configSo.stats.defenseGroup.apoptosisResistance;
        stats.defenseGroup.erosionResistance = configSo.stats.defenseGroup.erosionResistance;
        stats.defenseGroup.frostResistance = configSo.stats.defenseGroup.frostResistance;
        stats.defenseGroup.burnResistance = configSo.stats.defenseGroup.burnResistance;

    }
    /// <summary>
    /// ��Ա����������װ�ط���
    /// </summary>
    private void StatsToLoad()
    {
        configSo.stats.healthGroup.maxHealth = stats.healthGroup.maxHealth;

        configSo.stats.offenseGroup.physicalDamage = stats.offenseGroup.physicalDamage;
        configSo.stats.offenseGroup.spellDamage = stats.offenseGroup.spellDamage;
        configSo.stats.offenseGroup.apoptosisDamage = stats.offenseGroup.apoptosisDamage;
        configSo.stats.offenseGroup.erosionDamage = stats.offenseGroup.erosionDamage;
        configSo.stats.offenseGroup.frostDamage = stats.offenseGroup.frostDamage;
        configSo.stats.offenseGroup.burnDamage = stats.offenseGroup.burnDamage;

        configSo.stats.defenseGroup.physicalDefense = stats.defenseGroup.physicalDefense;
        configSo.stats.defenseGroup.spellResistance = stats.defenseGroup.spellResistance;
        configSo.stats.defenseGroup.apoptosisResistance = stats.defenseGroup.apoptosisResistance;
        configSo.stats.defenseGroup.erosionResistance = stats.defenseGroup.erosionResistance;
        configSo.stats.defenseGroup.frostResistance = stats.defenseGroup.frostResistance;
        configSo.stats.defenseGroup.burnResistance = stats.defenseGroup.burnResistance;
    }
}
