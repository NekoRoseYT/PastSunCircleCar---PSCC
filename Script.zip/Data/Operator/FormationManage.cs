using System.Collections.Generic;
using UnityEngine;

public class FormationManage
{
    public static FormationManage Instance { get; private set; } = new FormationManage();

    private List<PlayOperatorData> formation_01;
    public static int _maxCapacity { get; private set; } = 12;
    private FormationManage()
    {
        List<PlayOperatorData> data;
        data = FormationFileManage.Load();
        if (data != null)
            formation_01 = data;
        else
            formation_01 = new List<PlayOperatorData>(_maxCapacity);
    }
    public bool Contains(PlayOperatorData data)
    {

        if (formation_01.Contains(data))
            return true;

        return false;
    }
    public void Add(PlayOperatorData data)
    {
        if (_maxCapacity <= formation_01.Count)
        {
            Debug.LogError("����������Գ������Ӹ�Ա��");
            return;
        }
        formation_01.Add(data);
    }
    public void Remove(PlayOperatorData data)
    {
        formation_01.Remove(data);
    }
    public void Clear()
    {
        formation_01.Clear();
    }
    public PlayOperatorData Get(int index)
    {
        return formation_01[index];
    }
    public List<PlayOperatorData> GetAll()
    {
        return formation_01;
    }
    public int Count()
    {
        return formation_01.Count;
    }
}
