using UnityEngine;

[CreateAssetMenu(fileName= "��ԱTexture_", menuName = "��Ա/��ԱTexture")]
public class OperatorTextureConfigSO : ScriptableObject
{
    public Sprite fullIllustration;
    public Sprite headPortrait;
    public Sprite deployIcon;
}
