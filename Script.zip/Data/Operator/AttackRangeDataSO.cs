using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
[CreateAssetMenu(menuName = "��Ա/������Χ", fileName = "������Χ_")]
public class AttackRangeDataSO : ScriptableObject
{
    [SerializeField]
    private AttackRange[] ranges;
    public Dictionary<OperatorAttackRangeType, AttackRange> rangeGroup;
    private void OnEnable()
    {
        rangeGroup = new Dictionary<OperatorAttackRangeType, AttackRange>();
        foreach (AttackRange range in ranges)
        {
            rangeGroup.Add(range.rangeType, range);
        }
    }
}
[Serializable]
public class AttackRange
{
    public OperatorAttackRangeType rangeType;
    [SerializeField]
    private Vector2Int[] range_Left;
    [SerializeField]
    private Vector2Int[] range_Up;
    [SerializeField]
    private Vector2Int[] range_Right;
    [SerializeField]
    private Vector2Int[] range_Down;

    public Vector2Int[] GetRange(OperatorDeployOrientationType deployO)
    {
        switch (deployO)
        {
            case OperatorDeployOrientationType.Left: return range_Left;
            case OperatorDeployOrientationType.Up: return range_Up;
            case OperatorDeployOrientationType.Right: return range_Right;
            case OperatorDeployOrientationType.Down: return range_Down;
            default:
                Debug.LogError("Ԥ����Ľ��������ֵ��Ϊö���е��κ�һ��");
                return null;
        }

    }
    public int GetRangeNumber()
    {
        return range_Left.Length;
    }
}