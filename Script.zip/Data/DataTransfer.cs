using System.Collections.Generic;
using UnityEngine;

public class DataTransfer : MonoBehaviour
{
    //[SerializeField]
    //public List<Operator> operators;
    [SerializeField]
    public List<Entity_ItemData> warehouse;
    public PlayOperatorData o;
    private void Awake()
    {
        //OperatorFileManage.Instance.LoadData();
        //if (operators != null)
        //    UpdateOperatorGroup();
        //else
        //    Debug.LogWarning(gameObject.itemName + "��operatorsΪnull");
        if (warehouse != null)
            UpdataWarehouseGroup();
        else
            Debug.LogError(gameObject.name + "��warehouseΪnull");
        //o = OperatorGroup.GetOperator(1);
    }
   
    //private void UpdateOperatorGroup()
    //{
    //    foreach (Operator op in operators)
    //    {
    //        OperatorGroup.AddOperator(op);
    //    }
    //}
    private void UpdataWarehouseGroup()
    {
        foreach(Entity_ItemData itemData in warehouse)
        {
            WarehouseGroup.instance.AddData(itemData);
        }
    }
}
