using UnityEngine;

public class PlatformGenerator : MonoBehaviour
{
    public GameObject parentObject;

    [SerializeField] private GameObject SetupObject;
    private Vector3 platformPosition;
    private Terrain[,] terrains;
    [SerializeField]
    private int terrainsWidth;
    [SerializeField]
    private int terrainsHeight;

    private void Awake()
    {
        // platformPosition = SetupObject.GetComponent<MeshRenderer>().bounds.size;
        TerrainsInitialize();
        TerrainManage.Instance.terrains = terrains;
        Vector3 boundsSize = terrains[0, 0].GetComponent<MeshRenderer>().bounds.size;
        Vector3 localScale = terrains[0, 0].transform.localScale;
        platformPosition = new Vector3(
            Mathf.Abs(terrains[0,1].transform.position.x - terrains[0,0].transform.position.x),
            boundsSize.y * localScale.y,
            Mathf.Abs(terrains[1,0].transform.position.z - terrains[0,0].transform.position.z)
        );
        
        TerrainManage.Instance.terrainSize = platformPosition;

    }
    /// <summary>
    /// ��������������󣬻�ȡTerrain���÷����ά����
    /// </summary>
    private void TerrainsInitialize()
    {
        int index = 0;
        Terrain[] terrainGroup = GetComponentsInChildren<Terrain>();
        terrains = new Terrain[terrainsHeight, terrainsWidth];
        for (int y = 0; y < terrainsHeight; y++)
        {
            for (int x = 0; x < terrainsWidth; x++)
            {
                terrains[y, x] = terrainGroup[index++];
                terrains[y, x].SetCurrentPosition(x, y);
            }
        }
    }

    [ContextMenu("���ɵ���")]
    private void PlayGeneratorPlatform()
    {
        platformPosition = SetupObject.GetComponent<MeshRenderer>().bounds.size;

        transform.parent = parentObject.transform;
        GeneratorPlatform();
    }
    private void GeneratorPlatform()
    {
        Vector3 currentPosition = transform.position;
        float platformX = platformPosition.x;
        for (int i = 0; i < terrainsHeight; i++)
        {
            for (int j = 0; j < terrainsWidth; j++)
            {
                Instantiate(SetupObject, currentPosition, Quaternion.identity, parentObject.transform).GetComponent<Terrain>();
                currentPosition.x += platformX;
            }
            currentPosition = new Vector3(transform.position.x, transform.position.y, currentPosition.z + platformPosition.z);
        }
    }

}
