using UnityEngine;

public class CoreArchitecture : EntityMayAttackArchitecture
{
    [SerializeField]
    private GameObject[] summoners;

    private int terrainDefaultLayer;

    protected override void Awake()
    {
        base.Awake();
    }
    protected override void Start()
    {
        base.Start();
        terrainDefaultLayer = currentTerrain.gameObject.layer;
        currentTerrain.gameObject.layer = LayerMask.NameToLayer("Default");
        currentTerrain.currentWalkable = false;
    }
    public override void Die()
    {
        base.Die();
        currentTerrain.gameObject.layer = terrainDefaultLayer;
        currentTerrain.currentWalkable = currentTerrain.terrainData.walkable;
        foreach(GameObject summoner in summoners)
        {
            summoner.transform.position = transform.position;
            Instantiate(summoner);
        }
    }
    public int GetSummonerSun()
    {
        return summoners.Length;
    }
}
