using System.Collections.Generic;
using UnityEngine;

public class UI_Warehouse : MonoBehaviour
{
    public GameObject item;
    public Transform itemParent;
    
    private void Awake()
    {
        
        if (item == null)
            Debug.LogError(gameObject.name + "��itemΪnull");
    }
    // Start is called before the first frame update
    void Start()
    {
        CreateItem();
    }
    public void CreateItem()
    {
        foreach (KeyValuePair<int, Entity_ItemData> kvp in WarehouseGroup.instance.GetAllData())
        {
            GameObject item = Instantiate(this.item, itemParent);
            UI_Item ui_item = item.GetComponent<UI_Item>();
            if (ui_item != null)
            {
                ui_item.itemData = kvp.Value;
                
            }
            else
                Debug.LogError(gameObject.name + "��UI_ItemΪnull");
        }
    }
}
