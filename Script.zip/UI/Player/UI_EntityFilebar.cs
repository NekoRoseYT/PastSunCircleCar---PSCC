using UnityEngine;
using UnityEngine.UI;

public class UI_EntityFilebar : MonoBehaviour
{
    private CombatEntity entity;
    private Slider slider;
    private Entity_Damage damage;
    void Awake()
    {
        entity = GetComponentInParent<CombatEntity>();
        damage = GetComponentInParent<Entity_Damage>();
        slider = GetComponent<Slider>();
    }
    void OnEnable()
    {
        damage.HealtUpdata += SliderUpdate;
    }
    private void OnDestroy()
    {
        damage.HealtUpdata -= SliderUpdate;
    }
    // Update is called once per frame
    private void SliderUpdate()
    {
        slider.value = entity.currentHealth / entity.maxHealth;
    }
}
