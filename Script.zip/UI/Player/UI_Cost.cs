using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_Cost : MonoBehaviour
{
    [SerializeField]
    private CostTimerLogic cost;
    [SerializeField]
    private Slider slider;
    [SerializeField]
    private TextMeshProUGUI costText;
    private void Awake()
    {
        slider = GetComponentInChildren<Slider>();
        costText = GetComponentInChildren<TextMeshProUGUI>();
    }
    private void Start()
    {
        PlayerDataManage.Instance.OnCostChange += UpdataCost;   
    }

    private void Update()
    {
        //��ǰ���� / Cost��ȡ�ٶ�
        slider.value = (cost.GetCostPresentTime() / cost.GetCostGainSpeed());//���½�������Ϣ
    }
    /// <summary>
    ///����CostUI��Ϣ
    /// </summary>
    private void UpdataCost(int cost)
    {
        costText.text = cost.ToString();
    }
    private void OnDestroy()
    {
        PlayerDataManage.Instance.OnCostChange -= UpdataCost;
    }
}
