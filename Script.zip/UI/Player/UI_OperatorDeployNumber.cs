using TMPro;
using UnityEngine;

public class UI_OperatorDeployNumber : MonoBehaviour
{
    [SerializeField]
    private TextMeshProUGUI deployNumberText;

    private void Start()
    {
        PlayerDataManage.Instance.OnDeployNumberChange += UpdataDeployNumber;
    }
    private void UpdataDeployNumber(int deployNumber)
    {
        deployNumberText.text = deployNumber.ToString();
    }
    private void OnDestroy()
    {
        PlayerDataManage.Instance.OnDeployNumberChange -= UpdataDeployNumber;
    }
}
