using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class UI_GameStatistics : MonoBehaviour
{
    [SerializeField]
    private TextMeshProUGUI sceneEnemySun;
    [SerializeField]
    private TextMeshProUGUI escapeEnemyMaxNumber;
    [Header("����������")]
    [SerializeField]
    private GameObject currentEscapeEnemyObject;//���currentEscapeEnemy�Ķ�����������
    [SerializeField]
    private TextMeshProUGUI currentEscapeEnemy;

    // Start is called before the first frame update
    void Start()
    {
        PlayerDataManage.Instance.OnSucceedResis += UiUpdata;
        UiUpdata();
    }
    void OnDestroy()
    {
        PlayerDataManage.Instance.OnSucceedResis -= UiUpdata;
    }
    private void UiUpdata()
    {
        PlayerDataManage dataManage = PlayerDataManage.Instance;
        if(dataManage.currentEscapeNumber>0)
        {
            currentEscapeEnemyObject.SetActive(true);
            currentEscapeEnemy.text = $"-{dataManage.currentEscapeNumber}";
        }
        sceneEnemySun.text = $"{dataManage.succeedResistNumber}/{dataManage.sceneEscapeEnemySun}";
        escapeEnemyMaxNumber.text = $"{dataManage.escapeEnemyMaxNumber}";
    }
}
