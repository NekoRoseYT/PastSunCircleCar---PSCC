using UnityEngine;

public class UI_OperatorDeployHeadPanel : MonoBehaviour
{
    [SerializeField]
    private GameObject operatorDeployHead;

    // Start is called before the first frame update
    void Start()
    {
        UI_OperatorDeployOrientation orientation = GetComponentInParent<Canvas>().GetComponentInChildren<UI_OperatorDeployOrientation>(true);
        foreach (PlayOperatorData data in FormationManage.Instance.GetAll())
        {
            if (data != null)
            {
                UI_OperatorHeadItem deployHead = Instantiate(operatorDeployHead, transform).GetComponent<UI_OperatorHeadItem>();
                deployHead.Initialize(data, orientation);
            }
            else
            {
                Debug.LogError("����������");
            }
        }
    }

}
