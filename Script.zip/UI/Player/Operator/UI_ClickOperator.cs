using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class UI_ClickOperator : UI_Clickable
{
    [SerializeField]
    private UI_OperatorRetreat retreatUi;
    
    void Awake()
    {
        retreatUi = GetComponentInChildren<UI_OperatorRetreat>(true);    
    }
    protected override void Click(PointerEventData eventData)
    {
        base.Click(eventData);
        retreatUi.gameObject.SetActive(true);
    }
}
