using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_OperatorDeployCooldown : MonoBehaviour
{
    private UI_OperatorHeadItem head;
    [SerializeField]
    private OperatorDeployCooldownLogic deployCooldown;
    [SerializeField]
    private Image slider;
    private TextMeshProUGUI text;
    void Awake()
    {
        head = GetComponentInParent<UI_OperatorHeadItem>();
        text = GetComponentInChildren<TextMeshProUGUI>();
        head.deployCooldown += EnableObject;
        gameObject.SetActive(false);
    }
    void OnEnable()
    {
        deployCooldown.updataTime += UiInfoUpdata;
        deployCooldown.onCooldownOver += DisableObject;
    }
    void OnDisable()
    {
        deployCooldown.updataTime -= UiInfoUpdata;
        deployCooldown.onCooldownOver -= DisableObject;
    }
    private void DisableObject()
    {
        gameObject.SetActive(false);
    }
    private void EnableObject()
    {
        gameObject.SetActive(true);
    }
    private void UiInfoUpdata(float msec,int time)
    {
        slider.fillAmount = msec;
        text.text = time.ToString();
    }
}
