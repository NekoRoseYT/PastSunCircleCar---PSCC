using System;
using System.IO;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UI_OperatorHeadItem : MonoBehaviour, IBeginDragHandler, IDragHandler
{
    public event Action deployCooldown;
    private OperatorDeployCooldownLogic cooldownLogic;
    public Image image;
    [SerializeField]
    private Color barkenColor;
    public int cost;
    public bool canDeploy;
    private Operator operatorObject;
    private UI_OperatorDeployOrientation deployOrientationUi;

    private PlayOperatorData operatorData;
    public int operatorDeployTime{get => operatorData.configSo.deployTime;}

    private void Awake()
    {
        image = GetComponent<Image>();
        cooldownLogic = GetComponentInChildren<OperatorDeployCooldownLogic>(true);
    }
    public void Initialize(PlayOperatorData data,UI_OperatorDeployOrientation deployOrientationUi)
    {
        operatorData = data;
        this.deployOrientationUi = deployOrientationUi;
        image.sprite = data.configSo.deployIcon;
    }

    private void OperatorObjectInitialize(PlayOperatorData operatorData,UI_OperatorDeployOrientation deployOrientationUi)
    {
        operatorObject = Instantiate(Resources.Load<GameObject>(Path.Combine("Operators", "Prefab", operatorData.id.ToString()))).GetComponent<Operator>();
        if (operatorObject == null)
        {
            Debug.LogError(operatorData.id + "��ԱԤ�������ʧ��");
        }

        operatorObject.data = operatorData;
        operatorObject.OperatorEnable += HeadBarken;
        operatorObject.OperatorDisable += HeadBrighten;
        operatorObject.OperatorDeploy += OperatorDeploy;
        operatorObject.OperatorDie += OperatorDie;
        operatorObject.deployOrientationUi = deployOrientationUi;
    }
    void OnEnable()
    {
        cooldownLogic.onCooldownOver += DeployInspect;
    }
    void OnDisable()
    {
        cooldownLogic.onCooldownOver -= DeployInspect;
    } 
    private void HeadBrighten(PlayOperatorData data)
    {
        image.color = Color.white;
    }
    private void HeadBarken(PlayOperatorData data)
    {
        image.color = barkenColor;
    }
    private void OperatorDeploy(Operator data)
    {
        canDeploy = false;
        gameObject.SetActive(false);
    }
    private void OperatorDie(Operator data)
    {
        gameObject.SetActive(true);
        deployCooldown?.Invoke();
    }
    /// <summary>
    /// ��鵱ǰ�Ƿ���Բ���
    /// </summary>
    private void DeployInspect()
    {
        PlayerDataManage dataManage = PlayerDataManage.Instance;
        if(dataManage.deployOperators.Count>=dataManage.GetOperatorDeployMaxNumber())
            canDeploy = false;
        else if(dataManage.GetCostNumber()<operatorData.configSo.cost)
            canDeploy = false;
        else if(!cooldownLogic.cooldownOver)
            canDeploy = false;
        else
            canDeploy = true;
    }
    //ͷ�����ڱ���קʱ�����Ա���󣬳�ʼ��Ա����Ϊ��ק״̬����Ȼ������ꡣ��ά�������߼���
    public void OnBeginDrag(PointerEventData eventData)
    {
        DeployInspect();
        if(!canDeploy)
            return;
        if(operatorObject == null)
            OperatorObjectInitialize(operatorData,deployOrientationUi);
        else if(PlayerDataManage.Instance.GetOperatorDeployMaxNumber() > 0)
            operatorObject.gameObject.SetActive(true);
    }

    public void OnDrag(PointerEventData eventData)
    {
    }
}
