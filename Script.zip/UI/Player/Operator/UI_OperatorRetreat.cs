using UnityEngine.EventSystems;

public class UI_OperatorRetreat : UI_Clickable
{
    private Operator data;

    void Start()
    {
        data = GetComponentInParent<Operator>();
    }

    protected override void Click(PointerEventData eventData)
    {
        base.Click(eventData);
        data.Retreat();
        gameObject.SetActive(false);
    }
}
