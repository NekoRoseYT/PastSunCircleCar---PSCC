using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// ����洢�����UI����Data��Ϣ
/// </summary>
public class UIDataManage : MonoBehaviour
{
    public static UIDataManage Instance { get; private set; }

    private Dictionary<string,UIPanelRoot> uiPool = new Dictionary<string,UIPanelRoot>(); //ui��
    [SerializeField]
    private Transform uiPoolTransform;
    [SerializeField]
    private Canvas canvas;
    public UIPanelRoot homeUiObject;

    protected void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
        DontDestroyOnLoad(gameObject);
    }
    public GameObject BackPrevious(UIPanelRoot preObj)
    {
        UIPanelRoot previousPanel = preObj.GetPreviousPanel().GetComponentInParent<UIPanelRoot>(true);
        UIDataManage.Instance.AddPoolUi(preObj);
        UIDataManage.Instance.RemovePoolUi(previousPanel);
        
        if ((previousPanel == UIDataManage.Instance.homeUiObject))//�����һ��uiΪhomeUi
        {
            UIDataManage.Instance.homeUiObject.gameObject.SetActive(true);
            UIDataManage.Instance.ClearAllUi();
            return null;
        }
        previousPanel.gameObject.SetActive(true);
        return previousPanel.GetObject();
    }
    /// <summary>
    /// ���UI��������UI����������Ӧ����UI
    /// </summary>
    public void ClearAllUi()
    {
        foreach (UIPanelRoot ui in uiPool.Values.ToArray())
        {
            RemovePoolUi(ui);
            if(ui != homeUiObject)
                Destroy(ui.gameObject);
        }
    }

    public bool EnableUi(UIPanelRoot ui)
    {
        if(ContainsPoolUi(ui))
        {
            ui.gameObject.SetActive(true);
            RemovePoolUi(ui);
            return true;
        }
        return false;
    }
    public void DisableUi(UIPanelRoot ui)
    {
        if (ContainsPoolUi(ui))
        {
            return;
        }
        AddPoolUi(ui);
        ui.gameObject.SetActive(false);

    }
    public UIPanelRoot GetPoolUi(UIPanelRoot ui)
    {
        uiPool.TryGetValue(ui.name, out UIPanelRoot uiPanel);
        return uiPanel;
    }
    public void AddPoolUi(UIPanelRoot ui)
    {
        uiPool.Add(ui.name,ui);
        ui.transform.parent = uiPoolTransform;
    }
    public void RemovePoolUi(UIPanelRoot ui)
    {
        uiPool.Remove(ui.name);
        if(ui.transform.parent is not null)
            ui.transform.parent = canvas.transform;
    }
    public bool ContainsPoolUi(UIPanelRoot ui)
    {
        Debug.Log(uiPool);
        return uiPool.ContainsKey(ui.name);
    }
}
