using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_MainInterface : MonoBehaviour
{
    private RectTransform rect;
    [SerializeField]
    [Range(0,0.05f)]
    private float rotationSensitivity;


    void Awake()
    {
        rect = GetComponent<RectTransform>();
    }

    // Update is called once per frame
    void Update()
    {
        float mouseX = Input.mousePosition.x;       
        rect.localEulerAngles = new Vector3(0,mouseX*rotationSensitivity,0);
    }
}
