using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// �����Ŀǰ���½�UI��Ч������ʹ��
/// </summary>
public class UI_VfxSwitch : UI_Switching
{
    public bool vfxBack;
    public UI_ChapterSelection chapter;
    protected override GameObject BackPrevious(UIPanelRoot preObj)
    {
        if(vfxBack)
        {
            chapter.ChapterVfxBack();
            vfxBack = false;
            return null;
        }
        else
        {
            return UIDataManage.Instance.BackPrevious(preObj);
        }
    }
}
