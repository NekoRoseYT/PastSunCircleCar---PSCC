using System.Collections;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UI_Login : MonoBehaviour
{
    private Image image;

    [SerializeField]
    private float startDuration;
    [SerializeField]
    private float duration;
    void Awake()
    {
        image = GetComponent<Image>();
    }

    public IEnumerator LoginStart()
    {
        yield return image.DOFade(1,startDuration).WaitForCompletion();
    }
    public IEnumerator LoginEnd()
    {
        yield return image.DOFade(0,duration).WaitForCompletion();
        gameObject.SetActive(false);
    }
}
