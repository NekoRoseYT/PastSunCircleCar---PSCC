using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// ����ʵ�ֵ��ui�ⲿ��ʧ���Ӧui��Ч����
/// </summary>
public class UI_ClickableClose : UI_Clickable
{
    [SerializeField]
    private GameObject targetUi;

    protected override void Click(PointerEventData eventData)
    {
        base.Click(eventData);
        targetUi.gameObject.SetActive(false);
    }
}
