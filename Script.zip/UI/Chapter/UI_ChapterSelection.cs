using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.Video;

/// <summary>
/// Ŀǰ�����½�UI��Ч�͹ؿ�����л�
/// </summary>
public class UI_ChapterSelection : UI_Switching
{
    [Header("�½�����")]
    private UI_FadeIn playVfx;
    [SerializeField]
    private UI_VfxSwitch vfxSwitch;

    private RectTransform rectTransform;
    private Vector2 defaultSize;
    private Vector2 toScreenScale;
    private Vector2 localPoint;
    public Image chapterImage;
    private Sprite defaultSprite;
    public Sprite intoSprite;
    private bool clickedState;
    private bool stateOk;
    protected override void Awake()
    {
        base.Awake();
        rectTransform = GetComponent<RectTransform>();
        playVfx = GetComponentInChildren<UI_FadeIn>(true);
        defaultSize = rectTransform.rect.size;
        defaultSprite = chapterImage.sprite;
    }
    private void Start()
    {
        playVfx.gameObject.SetActive(false);
        //������Ļ���ĵ�λ�ڱ��ص�����
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            rectTransform.parent as RectTransform, new Vector2(Screen.width / 2, Screen.height / 2), Camera.main, out localPoint
        );
        //��ȡ�Ŵ�ϵ��
        toScreenScale = new Vector2(Screen.width / rectTransform.rect.width, Screen.height / rectTransform.rect.height) + new Vector2(1, 1);

    }

    public void ChapterVfxBack()
    {
        rectTransform.DOSizeDelta(rectTransform.rect.size / toScreenScale,0.5f);
        SpriteSwitch(defaultSprite,false);
        clickedState = false;
    }
    protected override void Click(PointerEventData eventData)
    {
        if (!clickedState) //��һ�ε��ʱ���Ŷ��������Ϊ�ѵ�����ȴ��ٴε������ui�л���
        {
            clickedState = true;
            vfxSwitch.chapter = this;
            rectTransform.DOSizeDelta(rectTransform.rect.size * toScreenScale, 0.5f);//�Ŵ���ȫ��
            rectTransform.DOAnchorPos(localPoint, 0.5f);//�ƶ����ĵ�λ�õ���Ļ����
            SpriteSwitch(intoSprite);
        }
        else if (stateOk)//��һ�α����ʱ���л�����һ��ui
        {
            base.Click(eventData);
        }
    }

    /// <summary>
    /// sprite�л�����
    /// </summary>
    /// <param name="sprite">Ŀ��sprite</param>
    /// <param name="isClick">�л��Ժ�״̬�Ƿ�ok���Ƿ�����½ڴ�״̬��</param>
    private void SpriteSwitch(Sprite sprite,bool isClick = true)
    {
        chapterImage.DOFade(0, 0.7f).OnComplete(
                        () =>
                        {
                            chapterImage.sprite = sprite;
                            chapterImage.DOFade(1, 0.5f).OnComplete(
                                () =>
                                {
                                    stateOk = isClick;
                                    vfxSwitch.vfxBack = isClick;
                                    playVfx.gameObject.SetActive(isClick);
                                }
                             );
                        }
                    );
    }
}
