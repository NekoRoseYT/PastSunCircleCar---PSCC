using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// ĿǰΪplay������Ŀ�ʼ��Ϸ��ť
/// </summary>
public class UI_StagePlay : UI_Clickable,IDataUser<string>
{
    [SerializeField]
    protected string sceneName;    
    protected bool isDestroy;
    [SerializeField]
    private GameObject loginPrefab;
    private UI_Login login;
    
    public void SetData(string data)
    {
        sceneName = data;
    }
    public string GetData()
    {
        return sceneName;
    }
    protected override void Click(PointerEventData eventData)
    {
        base.Click(eventData);
        UIPanelRoot panelRoot = gameObject.GetComponentInParent<UIPanelRoot>();
        UIDataManage.Instance.BackPrevious(panelRoot);
        SceneManage.Instance.LoadScene(sceneName,false,OnStart,OnComlete);
    }
    protected virtual IEnumerator OnStart()
    {

        yield return SceneManage.Instance.LoginStart();
    }
    protected virtual IEnumerator OnComlete()
    {
        yield return SceneManage.Instance.LoginEnd();
        SceneManage.Instance.DisableScene(gameObject.scene.name); //���ӳ�����ʧ��ɳ���ȫ������
    }
}
