using UnityEngine;

public class UI_StageConnectLine : MonoBehaviour
{
    [SerializeField]
    private RectTransform parentTransform;
    [SerializeField]
    private RectTransform initialTransform;
    [SerializeField]
    private RectTransform pointToTransform;

    [ContextMenu("�������������λ��")]
    private void LineUpdata()
    {
        Vector2 direction = pointToTransform.position - initialTransform.position;

        float angle = Mathf.Atan2(direction.x, direction.y) * Mathf.Rad2Deg;

        initialTransform.rotation = Quaternion.Euler(0, 0, angle);
    }
}
