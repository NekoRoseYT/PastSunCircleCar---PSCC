using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_Item : MonoBehaviour
{
    public Entity_ItemData itemData;
    public TextMeshProUGUI itemNumberText;
    public Image itemUI;
    private void Awake()
    {
        if (itemNumberText == null) Debug.LogError(gameObject.name + "��UI_Itemδ����TextMeshProUGUIL�ű�");
        
    }
    // Start is called before the first frame update
    void Start()
    {
        //itemData = GetComponent<Entity_ItemData>();
        if (itemUI.sprite == null)
        {
            itemUI.sprite = itemData.dataSo.sprite;
            gameObject.name = itemData.dataSo.itemName;
        }
        itemNumberText.text = UIFormatTool.QuantityTextRetract(itemData.quantity);
    }
    [ContextMenu("����UI")]
    private void UpdataUI()
    {
        itemData = GetComponent<Entity_ItemData>();
        if (itemData != null)
        {
            if (itemData.dataSo != null && itemUI != null)
            {
                itemUI.sprite = itemData.dataSo.sprite;
                gameObject.name = itemData.dataSo.itemName;
            }
        }
    }
}
