using DG.Tweening;
using UnityEngine;

/// <summary>
/// ui��˸Ч����
/// </summary>
public class UI_FadeIn : MonoBehaviour 
{
    private CanvasGroup canvas;
    private Tweener runTheAnimation;
    [SerializeField]
    private bool whetherFlicker;
    [SerializeField]
    private float interval;
    [SerializeField]
    private float diaphaneity;
    private void Awake()
    {
        canvas = GetComponent<CanvasGroup>();
        canvas.alpha = 0;
    }
    private void OnEnable()
    {
        canvas.DOFade(diaphaneity, interval);
    }
    private void Start()
    {
        if (whetherFlicker)
            runTheAnimation = canvas.DOFade(diaphaneity, interval)
                .SetLoops(-1, LoopType.Yoyo)
                .SetEase(Ease.Linear);

    }
    private void OnDisable()
    {
        canvas.alpha = 0;
    }
    private void OnDestroy()
    {
        runTheAnimation.Kill();
    }
}
