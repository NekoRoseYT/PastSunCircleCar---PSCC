using UnityEngine;

public class UIPanelRoot : MonoBehaviour, IUIPanel
{
    private GameObject previousPanel;
    public GameObject GetObject()
    {
        return gameObject;
    }

    public GameObject GetPreviousPanel()
    {
        return previousPanel;
    }


    public void SetPreviousPanel(GameObject panel)
    {
        previousPanel = panel;
    }

    public void ShowUi()
    {
        gameObject.SetActive(true);
    }
    public void HideUi()
    {
        gameObject.SetActive(false);
    }

}
