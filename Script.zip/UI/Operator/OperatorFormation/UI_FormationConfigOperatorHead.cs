using UnityEngine;
using UnityEngine.EventSystems;

public class UI_FormationConfigOperatorHead : UI_Clickable,IDataUser<PlayOperatorData>
{
    private UI_FormationOperatorSelectPanel selectPanel;

    public int formationNumber;
    private PlayOperatorData operatorData;
    public GameObject optForVfx;
    public bool whetherChecked;

    private void Awake()
    {
        selectPanel = GetComponentInParent<UI_FormationOperatorSelectPanel>();
    }
    // Start is called before the first frame update
    private void OnEnable()
    {
        if (operatorData != null)
        {
            Initialize();
        }
    }
    // void Start()
    // {
    //     operatorData = GetComponent<UI_OperatorHead>().operatorData;
    //     Initialize();
    // }
    private void Initialize()
    {
        if(FormationManage.Instance.Contains(operatorData))
            whetherChecked = true;
        CreateOptForVfx();
        CacheOperatorData();
    }
    protected override void Click(PointerEventData eventData)
    {
        base.Click(eventData);
        whetherChecked = !whetherChecked;
        CreateOptForVfx();
        CacheOperatorData();
    }
    public void CreateOptForVfx()
    {
        if (whetherChecked) //�ж�ѡ��״̬������vfx��ʾ
        {
            optForVfx.SetActive(true);
        }
        else
        {
            optForVfx.SetActive(false);
        }
    }
    /// <summary>
    /// ����Ա��Ϣ���뻺����
    /// </summary>
    private void CacheOperatorData()
    {
        if (whetherChecked)
        {
            selectPanel.operatorDatas.Add(operatorData); 
        }
        else
            selectPanel.operatorDatas.Remove(operatorData);
    }

    public void SetData(PlayOperatorData data)
    {
        operatorData = data;
        Initialize();
    }

    public PlayOperatorData GetData()
    {
        return operatorData;
    }
}
