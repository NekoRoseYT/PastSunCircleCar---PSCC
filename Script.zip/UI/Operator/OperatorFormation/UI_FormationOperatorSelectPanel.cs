using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_FormationOperatorSelectPanel : UIPanelRoot
{
    public List<PlayOperatorData> operatorDatas;

    void OnDisable()
    {
        operatorDatas.Clear();
    }
}
