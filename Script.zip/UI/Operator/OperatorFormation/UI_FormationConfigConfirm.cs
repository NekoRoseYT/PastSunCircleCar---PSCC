using UnityEngine.EventSystems;
using UnityEngine;
public class UI_FormationConfigConfirm : UI_Switching
{
    private UI_FormationOperatorSelectPanel selectPanel;
    [SerializeField]
    private UI_Switching backUi;
    protected override void Awake()
    {
        base.Awake();
        selectPanel = GetComponentInParent<UI_FormationOperatorSelectPanel>();
        backPrevious = true;
        
    }
    protected override void Click(PointerEventData eventData)
    {

        FormationManage f = FormationManage.Instance;
        f.Clear();
        foreach (PlayOperatorData data in selectPanel.operatorDatas)
        {
            f.Add(data);    
        }
        FormationFileManage.Save(f.GetAll());
        base.Click(eventData);
    }
    //public override void OnPointerUp(PointerEventData eventData)
    //{
    //    if (MousePositionCalculate())
    //    {
    //        foreach (PlayOperatorData data in selectPanel.operatorDatas)
    //        {
    //            if (!FormationManage.Instance.Contains(data))
    //            {
    //                FormationManage.Instance.Add(data);
    //            }
    //        }
    //        Switching();
    //        DestroyUI();
    //    }
    //}
}
