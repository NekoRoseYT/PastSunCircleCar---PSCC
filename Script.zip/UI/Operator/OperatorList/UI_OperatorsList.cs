using UnityEngine;

public class UI_OperatorsList : MonoBehaviour
{
    [SerializeField]
    protected GameObject operatorHead;

    // Start is called before the first frame update
    void Start()
    {
        CreateOperatorsHead();
    }
    protected virtual void CreateOperatorsHead()
    {
        foreach (PlayOperatorData operatorData in OperatorGroup.Instance.GetAllOperators())
        {
            NewHeadObject(operatorData); Debug.Log(operatorData);
        }
    }

    protected virtual void NewHeadObject(PlayOperatorData operatorData)
    {
        GameObject operatorInfo = Instantiate(operatorHead, transform);
        IDataUser<PlayOperatorData>[] headObjs = operatorInfo.GetComponents<IDataUser<PlayOperatorData>>();
        if (headObjs != null)
        {
            foreach(IDataUser<PlayOperatorData> headObj in headObjs)
            {
                headObj.SetData(operatorData);
            }
        }
        else
            Debug.LogWarning("������OperatorHead��û�й���UI_OperatorHead�ű���");
    }
}
