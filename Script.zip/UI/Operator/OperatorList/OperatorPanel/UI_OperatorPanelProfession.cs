using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_OperatorPanelProfession : MonoBehaviour,IDataUser<PlayOperatorData>
{
    private PlayOperatorData operatorData;
    [SerializeField]
    private Image icon;
    [SerializeField]
    private GameObject attackRange;
    private GameObject currentRange;
    [SerializeField]
    private TextMeshProUGUI attackLocation;
    [SerializeField]
    private TextMeshProUGUI character;

    void OnDisable()
    {
        currentRange.SetActive(false);
    }
    private void Initialize()
    {
        
        icon.sprite = operatorData.configSo.professionIcon;
        currentRange = Instantiate(operatorData.configSo.attackRange_Ui, attackRange.transform);
        AttackPositionTextInitialize();
    }

    private void AttackPositionTextInitialize()
    {
        if (operatorData.configSo.deployType == OperatorDeployType.Ground)
            attackLocation.text = "��սλ";
        else if (operatorData.configSo.deployType == OperatorDeployType.HighGround)
            attackLocation.text = "Զ��λ";
        else
            attackLocation.text = "���λ";
    }

    public void SetData(PlayOperatorData data)
    {
        operatorData = data;
        Initialize();
    }

    public PlayOperatorData GetData()
    {   
        return operatorData;
    }
}
