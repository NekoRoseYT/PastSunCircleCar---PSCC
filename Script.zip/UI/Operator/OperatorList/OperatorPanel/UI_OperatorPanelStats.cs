using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class UI_OperatorPanelStats : MonoBehaviour,IDataUser<PlayOperatorData>
{
    [SerializeField]
    private TextMeshProUGUI health;
    [SerializeField]
    private TextMeshProUGUI deployTime;
    [SerializeField]
    private TextMeshProUGUI attack;
    [SerializeField]
    private TextMeshProUGUI cost;
    [SerializeField]
    private TextMeshProUGUI defense;
    [SerializeField]
    private TextMeshProUGUI resist;
    [SerializeField]
    private TextMeshProUGUI spellResistance;
    [SerializeField]
    private TextMeshProUGUI attackSpeedText;

    private PlayOperatorData operatorData;

    void OnEnable()
    {
        if(operatorData != null)
            Initialize();
    }
    private void Initialize()
    {
        InitializePanelStats(); 
    }

    private void InitializePanelStats()
    {
        health.text = operatorData.stats.healthGroup.maxHealth.ToString();
        DeployTimeText();
        attack.text = operatorData.stats.offenseGroup.physicalDamage.ToString();
        cost.text = operatorData.configSo.cost.ToString();
        defense.text = operatorData.stats.defenseGroup.physicalDefense.ToString();
        resist.text = operatorData.configSo.resist.ToString();
        spellResistance.text = operatorData.stats.defenseGroup.spellResistance.ToString();
        AttackSpeedText();
    }
    private void DeployTimeText()
    {
        OperatorDeployTimeType deployTimeType = operatorData.configSo.deployTimeType;
        switch (deployTimeType)
        {
            case OperatorDeployTimeType.VerySlow:
                deployTime.text = "�ǳ���";
                break;
            case OperatorDeployTimeType.Slow:
                deployTime.text = "��";
                break;
            case OperatorDeployTimeType.Medium:
                deployTime.text = "�е�";
                break;
            case OperatorDeployTimeType.Fast:
                deployTime.text = "��";
                break;
            case OperatorDeployTimeType.VeryFast:
                deployTime.text = "�ǳ���";
                break;
        }
    }
    private void AttackSpeedText()
    {
        float attackSpeed = operatorData.configSo.attackSpeed;

        if ((attackSpeed >= 1.6f))
            attackSpeedText.text = "��";
        else if (attackSpeed <= 1.2f && attackSpeed <= 1.6f)
            attackSpeedText.text = "����";
        else if (attackSpeed <= 1.2f && attackSpeed >= 1f)
            attackSpeedText.text = "�е�";
        else if (attackSpeed <= 1f && attackSpeed >= 0.8f)
            attackSpeedText.text = "��";
        else if (attackSpeed <= 0.8f)
            attackSpeedText.text = "�ǳ���";
    }

    public void SetData(PlayOperatorData data)
    {
        operatorData = data;
        Initialize();
    }

    public PlayOperatorData GetData()
    {
        return operatorData;
    }
}
