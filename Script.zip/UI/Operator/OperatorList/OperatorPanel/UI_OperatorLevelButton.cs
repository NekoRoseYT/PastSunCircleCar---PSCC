using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_OperatorLevelButton : MonoBehaviour,IDataUser<PlayOperatorData>
{
    private PlayOperatorData operatorData;
    private UI_OperatorDataSwitch uiSwitch;
    private void Awake()
    {
        uiSwitch = GetComponent<UI_OperatorDataSwitch>();
    }

    private void Initialize()
    {
        uiSwitch.operatorData = operatorData;
    }

    public void SetData(PlayOperatorData data)
    {
        operatorData = data;
        Initialize();
    }

    public PlayOperatorData GetData()
    {
        return operatorData;    
    }
}
