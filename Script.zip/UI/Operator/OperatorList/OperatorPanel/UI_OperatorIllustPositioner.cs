using UnityEngine;
using UnityEngine.UI;

public class UI_OperatorIllustPositioner : MonoBehaviour,IDataUser<PlayOperatorData>
{
    private RectTransform rectTransform;
    private PlayOperatorData operatorData;
    [SerializeField]
    private Image fullIllustration;
    public Vector2 IllusPosition;
    public Vector2 IllusSize;
    private void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
        fullIllustration = GetComponent<Image>();
        if (rectTransform == null)
            Debug.LogError(gameObject.name+"δ����RectTransform");
        if (fullIllustration == null)
            Debug.LogError(gameObject.name + "δ����Image���");
    }

    private void Initialize()
    {
        UpdateIllustPosition();
        fullIllustration.sprite = operatorData.configSo.fullIllustration;
    }

    private void UpdateIllustPosition()
    {
        rectTransform.anchoredPosition = IllusPosition;
        rectTransform.sizeDelta = IllusSize;
    }
    [ContextMenu("���²�ͼλ�ã����ԣ�")]
    private void TestIllusPosition()
    {
        RectTransform rectTransform = GetComponent<RectTransform>();
        Image fullIllustration = GetComponent<Image>();

        IllusPosition = rectTransform.anchoredPosition;
        IllusSize = rectTransform.sizeDelta;
    }

    public void SetData(PlayOperatorData data)
    {
        operatorData = data;
        Initialize();    
    }

    public PlayOperatorData GetData()
    {
        return operatorData;    
    }
}
