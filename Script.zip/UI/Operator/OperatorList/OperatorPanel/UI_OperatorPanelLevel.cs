using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_OperatorPanelLevel : MonoBehaviour,IDataUser<PlayOperatorData>
{
    private PlayOperatorData operatorData;
    [SerializeField]
    private Image levelSlider;
    [SerializeField]
    private TextMeshProUGUI level;
    [SerializeField]
    private TextMeshProUGUI exp;

    void OnEnable()
    {
        if(operatorData != null)
            Initialize();
    }
    private void Initialize()
    {
        LevelSlider();
        LevelText();
        ExpText();
    }

    private void ExpText()
    {
        string maxExp = operatorData.configSo.levelSystem.maxExp.ToString();
        string presentExp = operatorData.configSo.levelSystem.presentExp.ToString();

        string coloredPresentExp = $"<color=#F9D766>{presentExp}</color>";

        exp.text = coloredPresentExp + " / " + maxExp;
    }
    private void LevelText() 
    {
        string levelText = operatorData.configSo.levelSystem.presentLevel.ToString();
        level.text = levelText;
    }
    private void LevelSlider()
    {
        int maxExp = operatorData.configSo.levelSystem.maxExp;
        int presentExp = operatorData.configSo.levelSystem.presentExp;
        if(maxExp == 0 || presentExp == 0)
        {
            LevelSliderInitialize();
            levelSlider.fillAmount = 0;
            return;
        }
        float expProgress = (float)(presentExp / maxExp);

        LevelSliderInitialize();
        levelSlider.fillAmount = expProgress;
    }
    private void LevelSliderInitialize()
    {
        levelSlider.type = Image.Type.Filled;
        levelSlider.fillMethod = Image.FillMethod.Radial360;
        levelSlider.fillOrigin = (int)Image.Origin360.Right;
        levelSlider.fillAmount = 0;
        levelSlider.fillClockwise = true;
    }

    public void SetData(PlayOperatorData data)
    {
        operatorData = data;
        Initialize();
    }

    public PlayOperatorData GetData()
    {
        return operatorData;
    }
}
