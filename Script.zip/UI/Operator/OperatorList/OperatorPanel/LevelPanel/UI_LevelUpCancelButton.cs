using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_LevelUpCancelButton : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
