using UnityEngine.EventSystems;

public class UI_LevelUpConfirmButton : UI_Clickable
{
    private IUIPanel levelPanelUi;
    private void Awake()
    {
        levelPanelUi = GetComponentInParent<UIPanelOperatorDataRoot>();
    }
    protected override void Click(PointerEventData eventData)
    {
        base.Click(eventData);
        if (LevelUpManager.Instance.LevelUp())
        {
            OperatorFileManage.SaveData(OperatorGroup.Instance);
            levelPanelUi.GetObject().SetActive(false);
            levelPanelUi.GetObject().SetActive(true);

        }
    }
}
