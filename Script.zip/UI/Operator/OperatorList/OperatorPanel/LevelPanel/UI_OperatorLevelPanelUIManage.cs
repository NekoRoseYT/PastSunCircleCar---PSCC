using TMPro;
using UnityEngine;
using DG.Tweening;

public class UI_OperatorLevelPanelUIManage : MonoBehaviour
{
    public RectTransform centerArows;
    public float centerArrowsMoveNumber;
    //public TextMeshProUGUI idelUIButtomText;
    //public GameObject upButtomUI;
    public GameObject idelUi;

    public GameObject upUi;
    // Start is called before the first frame update
    void Start()
    {
        //�����¼�
        UI_LevelUp.OnStartRoll += CenterArowsOnStart;
        UI_LevelUp.OnEndRoll += CenterArowsOnEnd;

        UI_LevelUp.OnStartRoll += UiSetActiveManageOnStart;

        UI_LevelUp.OnEndRoll += UiSetActiveManageOnEnd;

    }
    private void OnDestroy()
    {
        //ж���¼�
        UI_LevelUp.OnStartRoll -= CenterArowsOnStart;
        UI_LevelUp.OnEndRoll -= CenterArowsOnEnd;

        UI_LevelUp.OnStartRoll -= UiSetActiveManageOnStart;

        UI_LevelUp.OnEndRoll -= UiSetActiveManageOnEnd;

    }
    private void CenterArowsOnStart()
    {
        centerArows.anchoredPosition += new Vector2(centerArrowsMoveNumber, 0);
    }
    private void CenterArowsOnEnd() 
    {
        centerArows.anchoredPosition -= new Vector2(centerArrowsMoveNumber, 0);
    }
    private void UiSetActiveManageOnStart()
    {
        idelUi.SetActive(false);
        upUi.SetActive(false);
    }
    private void UiSetActiveManageOnEnd()
    {
        upUi.SetActive(true);
    }

}
