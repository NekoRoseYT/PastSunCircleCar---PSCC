using TMPro;
using UnityEngine;

public class UI_OperatorLevelUPPanelStats : MonoBehaviour, IDataUser<PlayOperatorData>
{
    private PlayOperatorData operatorData;
    [Header("����")]
    [SerializeField]
    private TextMeshProUGUI presentInformation;
    [SerializeField]
    private TextMeshProUGUI laterInformation;

    [Header("�ȼ��;���")]
    [SerializeField]
    private TextMeshProUGUI operatorLevelText;
    [SerializeField]
    private TextMeshProUGUI operatorExpText;
    [SerializeField]
    private TextMeshProUGUI expRequriedText;
    // Start is called before the first frame update
    private void Awake()
    {
        UI_LevelUp.OnEndRoll += ExpRequriedTextActivate;
    }
    void OnEnable()
    {
        if(operatorData != null)
        {
            OperatorStatsInitialize();
        }

    }
    private void OnDestroy()
    {
        UI_LevelUp.OnEndRoll -= ExpRequriedTextActivate;

    }
    /// <summary>
    /// stats������ϢUI��ʼ��
    /// </summary>
    public void OperatorStatsInitialize()
    {
        OperatorStatsInformationInitialize(presentInformation);
        OperatorStatsInformationInitialize(laterInformation);
        OperatorLevelAndExpInitialize();
    }
    /// <summary>
    /// ������ϢUI��ʼ��
    /// </summary>
    /// <param itemName="initializeText"></param>
    private void OperatorStatsInformationInitialize(TextMeshProUGUI initializeText)
    {
        string presentInfoText = $"<color=#FFFFFF>{operatorData.stats.healthGroup.maxHealth}\n</color>" +
                                 $"<color=#FFFFFF>{operatorData.stats.offenseGroup.physicalDamage}\n</color>" +
                                 $"<color=#FFFFFF>{operatorData.stats.defenseGroup.physicalDefense}\n</color>" +
                                 $"<color=#FFFFFF>{operatorData.stats.defenseGroup.spellResistance}\n</color>";

        initializeText.text = presentInfoText;
    }
    /// <summary>
    /// ������ϢUI��ʼ��
    /// </summary>
    private void OperatorLevelAndExpInitialize()
    {
        string presentLevelText = " " + operatorData.configSo.levelSystem.presentLevel;
        string presentExpText = " " + operatorData.configSo.levelSystem.presentExp;
        string maxExpText = "/" + operatorData.configSo.levelSystem.maxExp;

        operatorLevelText.text = "LV " + presentLevelText;
        operatorExpText.text = "EXP - " + presentExpText + maxExpText;
    }
    /// <summary>
    /// ������ʾ�Ʋ⵽Ŀ��ȼ�����ľ��顢����Ŀ��ȼ���ʣ�ྭ�顢Ŀ��ȼ������ֵ��Ŀ��ȼ���ֵ
    /// </summary>
    /// <param itemName="upgradePreviewData"></param>
    public void PreviewOperatorLevelAndExpInformationInitialize(UpgradePreviewData upgradePreviewData)
    {
        operatorLevelText.text = "LV " + upgradePreviewData.targetLevel;
        if (upgradePreviewData.targetLevel != operatorData.configSo.levelSystem.presentLevel)
            expRequriedText.text = $"<color=#FFA500>+ {upgradePreviewData.expRequried}</color>";
        else
            expRequriedText.gameObject.SetActive(false);
        if (upgradePreviewData.targetLevel != operatorData.configSo.levelSystem.maxLevel)
        {
            operatorExpText.text = "EXP - " + upgradePreviewData.levelUpResidueExp + " / " + upgradePreviewData.levelUpResidueMaxExp;
        }
        else
        {
            operatorExpText.text = "EXP - " + $"<color=#FFA500>-</color>" + " / -";
        }
    }

    /// <summary>
    /// �Ʋ�������Ŀ��ȼ���UI��Ϣ����
    /// </summary>
    /// <param itemName="upgradeStats"></param>
    public void PreviewOperatorStatsInformationInitialize(UpgradeStats upgradeStats)
    {
        StatsData stats = operatorData.stats;
        string pressentTextColor = "#FFFFFF";
        string prebiewTextColor = "#1E90FF";
        string prebiewHealthColor = stats.healthGroup.maxHealth != upgradeStats.health ? prebiewTextColor : pressentTextColor;
        string prebiewDamageColor = stats.offenseGroup.physicalDamage != upgradeStats.damage ? prebiewTextColor : pressentTextColor;
        string prebiewDefenseColor = stats.defenseGroup.physicalDefense != upgradeStats.defense ? prebiewTextColor : pressentTextColor;
        string prebiewSpellResistanceColor = stats.defenseGroup.spellResistance != upgradeStats.spellResistance ? prebiewTextColor : pressentTextColor;

        string previewInfoText = $"<color={prebiewHealthColor}>{upgradeStats.health}\n</color>" +
                                 $"<color={prebiewDamageColor}>{upgradeStats.damage}\n</color>" +
                                 $"<color={prebiewDefenseColor}>{upgradeStats.defense}\n</color>" +
                                 $"<color={prebiewSpellResistanceColor}>{upgradeStats.spellResistance}\n</color>";
        laterInformation.text = previewInfoText;
    }
    private void ExpRequriedTextActivate()
    {
        expRequriedText.gameObject.SetActive(true);
    }

    public void SetData(PlayOperatorData data)
    {
        this.operatorData = data;
        OperatorStatsInitialize();
    }
    public PlayOperatorData GetData()
    {
        return operatorData;
    }
}
