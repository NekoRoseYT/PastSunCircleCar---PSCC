using System.Collections.Generic;
using TMPro;
using UnityEngine;

/// <summary>
/// �������_����������
/// </summary>
public class UI_LevelNumberCreate : MonoBehaviour, IDataUser<PlayOperatorData>
{
    private PlayOperatorData operatorData;
    public int createNumber;
    public GameObject numberPrefab;
    public GameObject TopSpacer;
    public GameObject BottomSpacer;

    public List<RectTransform> levelNumberList;
    //private RectTransform presentTopSpacer;
    private RectTransform presentBottomSpacer;

    private bool isInitialize;

    private void Awake()
    {
        TopSpacer = Instantiate(TopSpacer, transform);
    }
    void OnEnable()
    {
        if(isInitialize)
            CreateNumberRun();
    }
    private void OnDisable()
    {
        DisableLevelNumber();
    }

    private void CreateNumberInitialize()
    {
        switch (operatorData.configSo.levelSystem.promotion)
        {
            case PromotionType.Zero:
                createNumber = OperatorLevelSystem.PROMOTION_MAXLEVEL_ZERO;
                break;
            case PromotionType.One:
                createNumber = OperatorLevelSystem.PROMOTION_MAXLEVEL_ONE;
                break;
            case PromotionType.Two:
                createNumber = OperatorLevelSystem.PROMOTION_MAXLEVEL_TWO;
                break;
        }

    }
    [ContextMenu("����LevelNumber")]
    public void CreateNumberRun()
    {

        for (int i = operatorData.configSo.levelSystem.presentLevel; i <= (createNumber + 1); i++)
        {
            if (i == createNumber + 1)
            {
                if(presentBottomSpacer == null)
                {
                    presentBottomSpacer = Instantiate(BottomSpacer, transform).GetComponent<RectTransform>();
                }
                else
                    presentBottomSpacer.gameObject.SetActive(true);
                break;
            }
            
            int currentNumber = i-operatorData.configSo.levelSystem.presentLevel;

            if (!isInitialize)
            {
                RectTransform number = Instantiate(numberPrefab, transform).GetComponent<RectTransform>();
                number.GetComponent<TextMeshProUGUI>().text = i.ToString();
                levelNumberList.Add(number);
            }
            else if(currentNumber >= levelNumberList.Count)
            {
                RectTransform number = Instantiate(numberPrefab, transform).GetComponent<RectTransform>();
                number.GetComponent<TextMeshProUGUI>().text = i.ToString();
                levelNumberList.Add(number);
            }
            else
            {
                TextMeshProUGUI tmp = levelNumberList[currentNumber].GetComponent<TextMeshProUGUI>();
                tmp.gameObject.SetActive(true);
                tmp.text = i.ToString();
                
            }
                
        }
    }
    public void DisableLevelNumber()
    {
        presentBottomSpacer.gameObject.SetActive(false);

        foreach (RectTransform number in levelNumberList)
        {
            number.gameObject.SetActive(false);
        }
    }

    public void SetData(PlayOperatorData data)
    {
        this.operatorData = data;
        CreateNumberInitialize();
        CreateNumberRun();
        isInitialize = true;
    }
    public PlayOperatorData GetData()
    {
        return operatorData;
    }
}
