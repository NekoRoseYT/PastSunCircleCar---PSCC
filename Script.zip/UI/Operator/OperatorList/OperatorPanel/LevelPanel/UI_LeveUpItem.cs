using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_LeveUpItem : MonoBehaviour
{
    [SerializeField]
    private GameObject item;
    private void Awake()
    {
        
    }
    [ContextMenu("����������ƷUI")]
    private void InsItem()
    {
        Entity_ItemData itemData;
        for (int i = 5; i > 0; i--)
        {
            itemData = WarehouseGroup.instance.GetData(i);
            UI_Item ui_item = Instantiate(item, transform).GetComponent<UI_Item>();
            ui_item.itemData = itemData;
        }
    }
}
