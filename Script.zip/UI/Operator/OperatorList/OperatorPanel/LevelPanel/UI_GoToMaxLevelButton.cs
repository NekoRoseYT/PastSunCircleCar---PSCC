using System;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UI_GoToMaxLevelButton : UI_Clickable
{
    public static event Action<PointerEventData> ToMaxLevel;
    public static event Action<PointerEventData> ToMaxLevelEnd;
    [Header("��������")]
    [SerializeField]
    private UI_LevelUp levelUp;
    private ScrollRect upLevelScrollRect;
    [SerializeField]
    private float scrollSpeed;
    private TextMeshProUGUI maxLevelText;
    private PlayOperatorData operatorData;

    private void Awake()
    {
        upLevelScrollRect = levelUp.GetComponent<ScrollRect>();
        maxLevelText = GetComponentInChildren<TextMeshProUGUI>();
    }
    // Start is called before the first frame update
    void Start()
    {
        operatorData = GetComponentInParent<IDataUser<PlayOperatorData>>().GetData();
    }

    public override void OnPointerDown(PointerEventData eventData)
    {
        base.OnPointerDown(eventData);
        ToMaxLevel?.Invoke(eventData);
    }
    protected override void Click(PointerEventData eventData)
    {
        base.Click(eventData);
        if (upLevelScrollRect != null)
        {
            upLevelScrollRect.verticalNormalizedPosition = 1f;
            ToMaxLevelEnd.Invoke(eventData);
        }
    }
}
