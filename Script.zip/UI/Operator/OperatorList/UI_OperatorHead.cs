using System;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class UI_OperatorHead : MonoBehaviour, IDataUser<PlayOperatorData>
{
    [NonSerialized]
    public PlayOperatorData operatorData;
    [SerializeField]
    private Image headPortrait;
    [SerializeField]
    private Image professionIcon;
    [SerializeField]
    private Image levelSlider;
    [SerializeField]
    private TextMeshProUGUI operatorLevelText;
    [SerializeField]
    private TextMeshProUGUI operatorNameText;


    private void Awake()
    {
        if (headPortrait == null)
            Debug.LogWarning("���ض���δ�ҵ�Image�ű�");
    }
    private void OnEnable()
    {
        if (operatorData != null)
        {
            Initialize();
            TransmitOperatorInfo();
        }
    }
    // private void Start()
    // {
    //     Initialize();
    //     TransmitOperatorInfo();
    // }
    private void Initialize()
    {
        if (headPortrait != null)
            headPortrait.sprite = operatorData.configSo.headPortrait;
        else
            Debug.LogWarning("OperatorΪnull");
        professionIcon.sprite = operatorData.configSo.professionIcon;
        levelSlider.fillAmount = operatorData.configSo.levelSystem.presentExp / operatorData.configSo.levelSystem.maxExp;
        operatorLevelText.text = operatorData.configSo.levelSystem.presentLevel.ToString();
        operatorNameText.text = operatorData.configSo.operatorName;
    }
    private void TransmitOperatorInfo()//��UI�л��ű����ݸ�Ա��Ϣ
    {
        UI_OperatorDataSwitch headSwitch = GetComponent<UI_OperatorDataSwitch>();
        if (headSwitch != null)
            headSwitch.operatorData = operatorData;
        else
            Debug.Log(gameObject.name + "����δʹ��UI_OperatorHeadSwitch�ű���������ʾ������bug������������Ϣ��");
    }

    public void SetData(PlayOperatorData data)
    {
        this.operatorData = data;
        Initialize();
        TransmitOperatorInfo();
    }
    public PlayOperatorData GetData()
    {
        return operatorData;
    }
}
