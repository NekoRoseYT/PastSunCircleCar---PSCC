using Spine;

public class Entity_DieState : Entity_State
{
    public Entity_DieState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        animation.loop = false;
        animation.AnimationState.Complete += Die;
    }
    private void Die(TrackEntry trackEntry)
    {
        entity.gameObject.SetActive(false);
        animation.loop = true;
    }
}
