using UnityEngine;

public class StateMachine
{
    private Entity_State state;
    public Entity_State currentState => state;
    public void Initialize(Entity_State state)
    {
        if (this.state != null)
            this.state.Exit();
        this.state = state;
        state.Enter();
    }
    public void CutState(Entity_State state)
    {
        this.state.Exit();
        this.state = state;
        state.Enter();
    }
    public void UpdataMachine()
    {
        state.Update();
    }

}
