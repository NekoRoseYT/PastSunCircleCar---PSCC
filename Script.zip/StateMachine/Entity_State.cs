using Spine;
using Spine.Unity;
using UnityEngine;
public class Entity_State
{
    protected Entity entity;
    protected string stateName;
    protected StateMachine machine;
    protected SkeletonAnimation animation;
    protected TrackEntry currentAnimation;
    public Entity_State(Entity entity, StateMachine machine,string stateName)
    {
        this.entity = entity;
        this.machine = machine;
        this.stateName = stateName;
        animation = entity.spineAnimation;
    }
    // Update is called once per frame
    public virtual void Update()
    {

    }
    public virtual void Enter()
    {
        currentAnimation = animation.state.SetAnimation(0, stateName, true);
    }
    public virtual void Exit()
    {
        animation.state.SetAnimation(0, "Idle", false);

    }
    public string a()
    {
        return stateName;
    }
    public Entity b()
    {
        return entity;
    }
}
