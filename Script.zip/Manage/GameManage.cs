using System;
using System.Collections;
using TMPro;
using UnityEngine;

public class GameManage : MonoBehaviour
{
    public static GameManage Instance;
    public Action<StageResultData> onGameEnd;
    [SerializeField]
    private GameObject gameOverUiPrefab;
    private GameObject gameOverUi;
    private TextMeshProUGUI gameOverUiText;
    [SerializeField]
    private Canvas canvas;
    public class StageResultData
    {
        public bool isWin;
        //SO�ļ�����Ÿ����ؿ��ڵĽ���SO��������Ϊʱ�������Ȳ�����
    }
    public StageResultData resultData {get;private set;}
    protected virtual void Awake()
    {
        if(Instance == null)
            Instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);
        resultData = new StageResultData();
    }

    public void ResultData(bool isWin)//�ڶ������������ݽ���SO�ļ�
    {
        resultData.isWin = isWin;
        onGameEnd?.Invoke(resultData);
    }
    public void GameOverUiCreate()
    {
        if(gameOverUi == null)
            gameOverUi = Instantiate(gameOverUiPrefab,canvas.transform);
        else
            gameOverUi.SetActive(true);
        gameOverUiText = gameOverUi.GetComponentInChildren<TextMeshProUGUI>();
        if (resultData.isWin)
        {
            gameOverUiText.text = "ս��ʤ��";
        }
        else
        {
            gameOverUiText.text = "ս��ʧ��";
        }
    }
}
