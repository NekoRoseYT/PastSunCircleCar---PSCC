using UnityEngine;

public class TimeManage : MonoBehaviour
{
    public static TimeManage Instance { get; private set; }
    private float defaultSpeed;

    
    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }
    // Start is called before the first frame update
    void Start()
    {
        defaultSpeed = Time.timeScale;
    }

    public void TimeOut()
    {
        if (Time.timeScale == defaultSpeed)
            Time.timeScale = 0;
        else
            Time.timeScale = defaultSpeed;
    }

    public void DoubleTime()
    {
        if (Time.timeScale == defaultSpeed)
        {
            Time.timeScale = defaultSpeed * 2;
        }
        else
        {
            Time.timeScale = defaultSpeed;
        }
    }
    public bool Timer(float targetTime,ref float presentTime)
    {
        presentTime += Time.deltaTime;
        if (presentTime >= targetTime)
        {
            presentTime = 0;
            return true;
        }
        return false;
    }
    
}
