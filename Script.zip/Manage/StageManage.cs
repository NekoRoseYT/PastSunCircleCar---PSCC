using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StageManage : MonoBehaviour
{
    public static StageManage Instance;
    private PlayerDataManage dataManage;

    [SerializeField]
    private string awardSO;//����SO����Ins�����϶�����������Ϊstring����Ϊʱ�����ޣ���ʱ������SO�ࡣ
    private string sceneName;
    private bool isDestroy = true;
    private bool isStageEnd;
    protected void Awake()
    {
        if(Instance == null)
        Instance = this;
        else
        {
            Destroy(gameObject);
        }
        sceneName = SceneManager.GetSceneByBuildIndex(0).name;
    }
    void Start()
    {
        dataManage = PlayerDataManage.Instance;
        dataManage.OnSucceedResis += GameVictoryCheck;

    }
    void OnDestroy()
    {
        dataManage.OnSucceedResis -= GameVictoryCheck;
    }
    private void GameVictoryCheck()
    {
        if(dataManage.succeedResistNumber >= dataManage.sceneEscapeEnemySun && !isStageEnd)
        {
            isStageEnd = true;
            GameManage.Instance.ResultData(true);
            SceneManage.Instance.BackScene(sceneName, OnStart, OnComplete);
        }
        else if (dataManage.currentEscapeNumber >= dataManage.escapeEnemyMaxNumber && !isStageEnd)
        {
            isStageEnd = true;
            GameManage.Instance.ResultData(false);//�ڶ����������ݵ�ǰ�����洢�Ľ���SO
            SceneManage.Instance.BackScene(sceneName, OnStart, OnComplete);
        }
    }
    private IEnumerator OnStart()
    {

        yield return SceneManage.Instance.LoginStart();
    }
    private IEnumerator OnComplete()
    {   
        GameManage.Instance.GameOverUiCreate();
        yield return SceneManage.Instance.LoginEnd();
        SceneManage.Instance.EnableScene(SceneManager.GetActiveScene().name);
    }
}
