using System.Collections.Generic;
using UnityEngine;

public class Enemy : Entity
{
    public EnemyConfigSO enemyConfigSO;

    public Rigidbody rb;
    private bool isFirst = true; //�Ƿ��ǵ�һ�γ�ʼ��

    [Header("�������")]
    public bool canSwitchTarget;//�Ƿ�����л�Ŀ��
    public List<Operator> planTargets {get;private set;}

    public Operator targetOperator;//Ŀ���Ա
    public Terrain targetTerrain;
    [SerializeField]
    private float _detectionRange;//���з�Χ
    public float detectionRange { get => _detectionRange; }

    [Header("�ƶ����")]
       public EnemyMoveType specialMoveType;//�����ƶ�����
    public float moveSpeed;//�ƶ��ٶ�
    public List<Terrain> path;//��ǰ�ƶ�·��

    public EnemyState idleState;
    public Enemy_MoveState moveState;
    public Enemy_AttackState attackState;

    public float terrainLocalOffset; //������λ��ƫ�ơ�
    public float attackSpeed{get => enemyConfigSO.attackSpeed;}
    protected override void Awake()
    {
        base.Awake();

        rb = GetComponent<Rigidbody>();

        canSwitchTarget = true;
        stats = enemyConfigSO.stats;
     
    }
    protected override void OnEnable()
    {
        base.OnEnable();
        if(isFirst) //����ǵ�һ�γ�ʼ��
            return;
        EnableInitialize();
    }
    
     protected override void Start()
    {
        base.Start();
        planTargets = new List<Operator>(PlayerDataManage.Instance.GetOperatorDeployMaxNumber());
        if (isFirst) //���Ƶ�һ�γ�ʼ����Start
        {
            Initialize();
            isFirst = false;
        }
        PlayerDataManage dataManage = PlayerDataManage.Instance;
        dataManage.AddGridEnemy(this);
        OperatorRangeDetector();
    }
    public void Initialize()
    {
        currentTerrain = TerrainManage.Instance.WordToTerrainsPosition(transform.position);
        machine.Initialize(idleState);
        currentHealth = maxHealth;
    }
    protected virtual void EnableInitialize()
    {
        Initialize();
    }
    /// <summary>
    /// ����Լ��Ƿ��ڸ�Ա������Χ�ڣ�����ھ�������빥��״̬��
    /// </summary>
    protected virtual void OperatorRangeDetector()
    {
        PlayerDataManage.Instance.attackRangeTerrains.TryGetValue(currentTerrain,out List<Operator> operators);
        if(operators!=null && operators?.Count > 0) //�����ǰ�����ڸ�Ա��Χ��
            foreach(Operator operatorData in operators) //������Ӧ��Ա���빥��״̬
                operatorData.OperatorAttack(currentTerrain);
    }
    
    public virtual void DisposeHighGroundTarget(Operator operatorData)
    {
        
    }
    protected override void InitializeState()
    {
        base.InitializeState();
        idleState = new Enemy_IdleState(this, machine, "Idle");
        moveState = new Enemy_MoveState(this, machine, "Move");
        attackState = new Enemy_AttackState(this, machine, "Idle");
    }
    public override void Die()
    {
        PlayerDataManage.Instance.gridEnemys[currentTerrain].Remove(this);
        if(targetOperator != null)
        {
            targetOperator.currentResist--;
            targetOperator.byRegardTargetNumber--;
        }
        rb.velocity = Vector3.zero;
        base.Die();
    }
}
