using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LongRangeEnemy : Enemy
{
    public bool isLongRange;
    public float longRange;
    public Operator longAttackTarget;
    public EnemyState lastState;

    protected override void InitializeState()
    {
        idleState = new LongRangeEnemy_IdleState(this,machine,"Idle");
        moveState = new LongRangeEnemy_MoveState(this,machine,"Move_Loop");
        attackState = new LongRangeEnemy_AttackState(this,machine,"Attack");
    }
    protected override void Update()
    {
        base.Update();

    }
    public virtual Operator LongAttackDetection()
    {
        //�������Ͼ����Լ�λ������ĸ�Ա����������
        TerrainManage terrainManage = TerrainManage.Instance;
        List<Operator> datas = PlayerDataManage.Instance.deployOperators;
        if(datas.Count <= 0)
            return null;
        Operator minDistanceOperator = datas[0];
        int minDistance = terrainManage.Heurstic(currentTerrain.GetCurrentPosition(), datas[0].currentTerrain.GetCurrentPosition()); ;
        int currentDistance;
        for (int i = 1; i < datas.Count; i++)
        {
            currentDistance = terrainManage.Heurstic(currentTerrain.GetCurrentPosition(), datas[i].currentTerrain.GetCurrentPosition());
            if (currentDistance < minDistance)
            {
                minDistance = currentDistance;
                minDistanceOperator = datas[i];
            }
        }
        return minDistanceOperator;

    }
}
