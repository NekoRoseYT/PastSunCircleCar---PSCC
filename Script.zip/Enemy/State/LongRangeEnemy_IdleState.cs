using UnityEngine;

public class LongRangeEnemy_IdleState : Enemy_IdleState
{
    protected LongRangeEnemy longEnemyData {get => enemyData as LongRangeEnemy;} 
  
    private float longAttackInterval;
    public LongRangeEnemy_IdleState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        longAttackInterval = 1 / longEnemyData.attackSpeed;
    }
    public override void Update()
    {
        base.Update();
        if(PlayerDataManage.Instance.deployOperators.Count > 0)
            longAttackInterval -= Time.deltaTime;
        if(longAttackInterval <= 0)
        {
            Operator minOperator = longEnemyData.LongAttackDetection();
            if (DistanceCompute(minOperator))
            {
                longEnemyData.isLongRange = true;
                longEnemyData.longAttackTarget = minOperator;
                machine.CutState(longEnemyData.attackState);
            }
        }
    }
    public override void Exit()
    {
        base.Exit();
        longEnemyData.lastState = this;
    }
}
