
public class EscapeEnemyState : EnemyState
{
    //��ȡת��ΪEscapeEnemy���͵�enemyData
    protected EscapeEnemy escapeEnemyData => enemyData as EscapeEnemy;
    public EscapeEnemyState(Enemy enemy, StateMachine machine, string stateName) : base(enemy, machine, stateName)
    {   
    }
    public override void Update()
    {
        base.Update();
        if(escapeEnemyData.currentTerrain.deployOperator != null && machine.currentState is not EscapeEnemy_BeBlockedState)
        {
            machine.CutState(escapeEnemyData.beBlockedState);
        }
    }
}
