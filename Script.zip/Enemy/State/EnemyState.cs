using UnityEngine;

public class EnemyState : Entity_State
{
    protected Enemy enemyData;
    protected Rigidbody rb;
    public EnemyState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
        enemyData = (Enemy)entity;
        rb = enemyData.GetComponent<Rigidbody>();
    }
    /// <summary>
    /// �Զ���ĳЩ������л�����״̬��
    /// </summary>
    protected virtual void CutState(){}

}
