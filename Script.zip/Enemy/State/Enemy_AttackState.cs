using Spine;
using UnityEngine;

public class Enemy_AttackState : EnemyState
{
    protected float attackInterval;
    protected bool isAttacking;
    protected float defaultSpeed;
    public Enemy_AttackState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        rb.velocity = Vector3.zero;
        attackInterval = 1 / enemyData.attackSpeed;
        defaultSpeed = animation.state.TimeScale;
        animation.state.Event += Attack;
        AttackDecide();
    }
    public override void Update()
    {
        base.Update();
        if (isAttacking)
            return;
        if (attackInterval > 0)
        {
            attackInterval -= Time.deltaTime;
            return;
        }
        AttackDecide();
    }

    protected virtual void AttackDecide()
    {
        if (enemyData.currentTerrain.deployOperator != null)
        {
            StartAttack();
        }
        else
        {
            machine.CutState(enemyData.idleState);
        }
    }

    protected virtual void StartAttack()
    {
        isAttacking = true;
        animation.state.SetAnimation(0, "Attack", false);
        animation.state.TimeScale = enemyData.enemyConfigSO.attackSpeed;
    }

    public override void Exit()
    {
        base.Exit();
        animation.state.TimeScale = defaultSpeed;
        animation.state.Event -= Attack;
        ClearTarget();
    }

    protected virtual void ClearTarget()
    {
        GamePlayTool.EnemyTargetClear(enemyData);
    }

    protected virtual void Attack(TrackEntry trackEntry,Spine.Event e)
    {
        TakeTarget();
        trackEntry.Complete += Reset;
    }

    protected virtual void TakeTarget()
    {
        enemyData.targetOperator.TakeDamage(enemyData.enemyConfigSO.stats.offenseGroup);
    }

    protected virtual void Reset(TrackEntry trackEntry)
    {
        trackEntry.Complete -= Reset;
        animation.state.SetAnimation(0, stateName, true);
        animation.state.TimeScale = defaultSpeed;
        attackInterval = 1 / enemyData.attackSpeed;
        isAttacking = false;
    }
}
