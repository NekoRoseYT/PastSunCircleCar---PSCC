using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscapeEnemy_BeBlockedState : EscapeEnemyState
{
    private float currentTime;
    public EscapeEnemy_BeBlockedState(EscapeEnemy enemy, StateMachine machine, string stateName) : base(enemy, machine, stateName)
    {
    }
    public override void Update()
    {
        base.Update();
        escapeEnemyData.rb.velocity = Vector3.zero;
        if(currentTime >= escapeEnemyData.beBlockedTime)
        {
            PlayerDataManage.Instance.SucceedResistNumber();
            escapeEnemyData.Die();
        }
        if(escapeEnemyData.currentTerrain.deployOperator == null)
        {
            machine.CutState(escapeEnemyData.moveState);
        }
        currentTime += Time.deltaTime;
    }
    public override void Exit()
    {
        base.Exit();
        currentTime = 0;
    }
}
