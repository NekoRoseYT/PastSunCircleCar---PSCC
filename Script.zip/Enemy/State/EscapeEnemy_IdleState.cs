using UnityEngine;

public class EscapeEnemy_IdleState : EscapeEnemyState
{
    private float currentTime;
    public EscapeEnemy_IdleState(EscapeEnemy enemy, StateMachine machine, string stateName) : base(enemy, machine, stateName)
    {
    }
    override public void Update()
    {
        //����Ǹմ�������ȴ�ʱ������Ժ����ƶ���
        if(enemyData.path.Count <= 0 && enemyData.currentTerrain.deployOperator == null)
        {
            if(currentTime >= escapeEnemyData.idleTime)
                machine.CutState(escapeEnemyData.moveState);
            else
                currentTime += Time.deltaTime;
        }else if(escapeEnemyData.currentTerrain.deployOperator == null && escapeEnemyData.path.Count > 0)
        {
            machine.CutState(escapeEnemyData.moveState);
        }
        else
        {
            machine.CutState(escapeEnemyData.beBlockedState);
        }
    }

}
