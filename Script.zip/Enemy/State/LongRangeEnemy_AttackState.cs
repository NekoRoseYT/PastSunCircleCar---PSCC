using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Spine;

public class LongRangeEnemy_AttackState : Enemy_AttackState
{
    protected LongRangeEnemy longEnemyData {get => enemyData as LongRangeEnemy;} 

    public LongRangeEnemy_AttackState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
    }

    public override void Enter()
    {
        base.Enter();
        if (longEnemyData.isLongRange)
        {
            StartAttack();
        }
    }
    public override void Exit()
    {
        base.Exit();
        longEnemyData.isLongRange = false;
        longEnemyData.longAttackTarget = null;
    }
    protected override void AttackDecide()
    {
        if(longEnemyData.isLongRange)
            return;
        base.AttackDecide();
    }
    protected override void TakeTarget()
    {
        if(longEnemyData.isLongRange)
        {
            
            longEnemyData.longAttackTarget.TakeDamage(longEnemyData.stats.offenseGroup);
        }
        else
            base.TakeTarget();
    }
    protected override void Reset(TrackEntry trackEntry)
    {
        base.Reset(trackEntry);
        if(longEnemyData.isLongRange)
        {
            machine.CutState(longEnemyData.lastState);
        }
    }
    protected override void ClearTarget()
    {
        if(!longEnemyData.isLongRange)
            base.ClearTarget();
    }
}
