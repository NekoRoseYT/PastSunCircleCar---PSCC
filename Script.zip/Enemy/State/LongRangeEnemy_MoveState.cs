using System.Collections.Generic;
using UnityEngine;

public class LongRangeEnemy_MoveState : Enemy_MoveState
{
    protected LongRangeEnemy longEnemyData { get => enemyData as LongRangeEnemy; }

    private bool isInitialize;
    private float loogAttackInterval;

    public LongRangeEnemy_MoveState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
    }
    public override void Enter()
    {
        loogAttackInterval = 1 / longEnemyData.attackSpeed;
        base.Enter();
    }
    public override void Update()
    {
        base.Update();
        loogAttackInterval -= Time.deltaTime;
        if (loogAttackInterval <= 0)
        {
            Operator minDistanceOperator = longEnemyData.LongAttackDetection();
            if (DistanceCompute(minDistanceOperator))
            {
                longEnemyData.isLongRange = true;
                longEnemyData.longAttackTarget = minDistanceOperator;
                loogAttackInterval = 1 / longEnemyData.attackSpeed;
                machine.CutState(longEnemyData.attackState);
            }
        }
    }
    public override void Exit()
    {
        base.Exit();
        longEnemyData.lastState = this;//�����ϸ�״̬Ϊ����
    }
    protected override void PathInitialize()
    {
        if (isInitialize)
            return;
        base.PathInitialize();
        isInitialize = true;
    }
    protected override void StateOver()
    {
        base.StateOver();
        isInitialize = false;
    }
    
}
