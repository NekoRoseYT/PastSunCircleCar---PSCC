using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscapeEnemy_MoveState : Enemy_MoveState
{
    private EscapeEnemy escapeEnemy => enemyData as EscapeEnemy;
    public EscapeEnemy_MoveState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
    }
    public override void Update()
    {
        base.Update();
        if(PlayerDataManage.Instance.escapeTerrains.Contains(escapeEnemy.currentTerrain))
        {
            PlayerDataManage.Instance.EnemyEscape();
            escapeEnemy.Die();
        }
    }
    protected override bool IsTargetLose()
    {
        return false;
    }
    protected override void CutState()
    {
        machine.CutState(escapeEnemy.beBlockedState);        
    }
}
