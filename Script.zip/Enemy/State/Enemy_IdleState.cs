using UnityEngine;

public class Enemy_IdleState : Enemy_OperatorTargetingState
{
    public Enemy_IdleState(Entity entity, StateMachine machine, string stateName) : base(entity, machine, stateName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        rb.velocity = Vector3.zero;
    }
    public override void Update()
    {
        base.Update();
        ResistDetection();
    }

    protected virtual void ResistDetection()
    {
        Operator target = enemyData.currentTerrain.deployOperator;
        if (target != null)
        {
            enemyData.targetOperator = target;
            enemyData.targetTerrain = target.currentTerrain;
            CutState();
        }
    }

    protected override void CutState()
    {
        base.CutState();
        machine.CutState(enemyData.attackState);
    }
}
