using UnityEngine;

public class EscapeEnemy : Enemy
{
    [Header("�ȴ�ʱ��")]
    public float idleTime;
    public float beBlockedTime;

    public EscapeEnemy_BeBlockedState beBlockedState;
    protected override void Awake()
    {
        base.Awake();
        canSwitchTarget = false;
    }
    protected override void Start()
    {
        base.Start();
        GetMinEscapePoint();
    }
    protected override void OnEnable()
    {
    }
    protected override void InitializeState()
    {
        idleState = new EscapeEnemy_IdleState(this, machine, "Idle");
        moveState = new EscapeEnemy_MoveState(this, machine, "Move");
        beBlockedState = new EscapeEnemy_BeBlockedState(this,machine,"Idle");
    }
    protected override void EnableInitialize()
    {
        base.EnableInitialize();
        GetMinEscapePoint();
    }
    protected override void OperatorRangeDetector()
    {
    }
    /// <summary>
    /// ��ȡ�������������
    /// </summary>
    private void GetMinEscapePoint()
    {
        
        PlayerDataManage dataManage = PlayerDataManage.Instance;
        TerrainManage terrainManage = TerrainManage.Instance;
        if(dataManage.escapeTerrains.Count == 0)
        {
            Debug.LogError("EscapeEnemy: δ������������");
            return;
        }
        if(dataManage.escapeTerrains.Count == 1)
        {
            targetTerrain = dataManage.escapeTerrains[0];
            return;
        }
        //�ҵ��������������
        Terrain minTerrain = dataManage.escapeTerrains[0];
        int minPrice = terrainManage.Heurstic(currentTerrain.GetCurrentPosition(),minTerrain.GetCurrentPosition());
        for(int i = 1;i < dataManage.escapeTerrains.Count;i++)
        {
            Terrain terrain = dataManage.escapeTerrains[i];
            int currentPrice = terrainManage.Heurstic(currentTerrain.GetCurrentPosition(),terrain.GetCurrentPosition());
            if(currentPrice < minPrice)
            {
                minTerrain = terrain;
                minPrice = currentPrice;
            }
        }
        targetTerrain = minTerrain;
    }
    public override void Die()
    {
        
        base.Die();

    }
}
