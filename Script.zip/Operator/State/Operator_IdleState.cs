using System.Collections.Generic;
using UnityEngine;
public class Operator_IdleState : OperatorState
{
    protected Dictionary<Terrain,List<IDamageable>> detectorTarget;
    public Operator_IdleState(Operator operatorData, StateMachine macchine, string stateName) : base(operatorData, macchine, stateName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        Debug.Log("����״̬��Ա");
        DetectorTargetInitialize();
        DetectorGroup();
    }

    protected void DetectorGroup()
    {
        Terrain targetTerrain = null;
        if (operatorData.data.configSo.attackNumber > 0)
            targetTerrain = RangeDetector();
        if (targetTerrain != null)
        {
            operatorData.OperatorAttack(targetTerrain);
        }
    }


    public override void Update()
    {
        base.Update();
    }
    /// <summary>
    /// ��ⷶΧ��ʼ������
    /// </summary>
    protected virtual void DetectorTargetInitialize()
    {
        detectorTarget = PlayerDataManage.Instance.gridEnemys;
    }
    /// <summary>
    /// ��ⷶΧ���Ƿ���ڵз���λ
    /// </summary>
    /// <returns></returns>
    protected virtual Terrain RangeDetector()
    {
        Terrain targetTerrain = TargetFind(detectorTarget,operatorData.attackRanges);
        
        if(targetTerrain != null)
            return targetTerrain;
        else
            return null;
    }
    /// <summary>
    /// ��������keyValues���Ƿ����terrainsԪ�ء������ҵ��ĵ�һ��List<IDamageable>�д���Ԫ�صĶ�Ӧ�ļ���
    /// </summary>
    /// <param name="keyValues"></param>
    /// <param name="terrains"></param>
    /// <returns></returns>
    protected virtual Terrain TargetFind(Dictionary<Terrain,List<IDamageable>> keyValues,Terrain[] terrains)
    {
        foreach(Terrain range in terrains)
        {
            if(keyValues.TryGetValue(range,out List<IDamageable> targets) && targets.Count > 0)
            {
                bool existCanDamage = false;
                foreach(IDamageable target in targets)
                {
                    if (IsValidTarget(target))
                    {
                        existCanDamage = true;
                        break;
                    }
                }
                if (existCanDamage)
                    return range;
            }
        }
        return null;
    }

    protected virtual bool IsValidTarget(IDamageable enemy)
    {
        return enemy.canByDamage;
    }
}
