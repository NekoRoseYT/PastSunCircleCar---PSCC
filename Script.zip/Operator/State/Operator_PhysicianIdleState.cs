
public class Operator_PhysicianIdleState : Operator_IdleState
{
    public Operator_PhysicianIdleState(Operator operatorData, StateMachine macchine, string stateName) : base(operatorData, macchine, stateName)
    {
    }
    public override void Update()
    {
        base.Update();
        DetectorGroup();
    }

    protected override void DetectorTargetInitialize()
    {
        detectorTarget = PlayerDataManage.Instance.gridCanCureOperators;
    }
    protected override bool IsValidTarget(IDamageable target)
    {
        return target.canByCure && target.IsMayCure();
    }
}
