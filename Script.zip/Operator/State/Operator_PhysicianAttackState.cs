using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Operator_PhysicianAttackState : Operator_AttackState
{

    public Operator_PhysicianAttackState(Operator operatorData, StateMachine machine, string stateName) : base(operatorData, machine, stateName)
    {
    }
    protected override void TargetFind()
    {
        rangeTargets.Clear();
        foreach(Terrain range in operatorData.attackRanges)
        {
            if(dataManage.gridCanCureOperators.TryGetValue(range,out List<IDamageable> targets))
            {
                if(rangeTargets.Count >= _attackNumber)
                    break;
                if(targets.Count > 0)
                {
                    foreach(IDamageable target in targets)
                    {
                        if(target.IsMayCure())
                            rangeTargets.Add(targets[0]);
                    }
                }
            }
        }
    }
    protected override void TakeTarget(IDamageable enemy)
    {
        enemy.TakeHealt(operatorData.stats.offenseGroup);
    }
}
