public class OperatorState : Entity_State
{
    protected Operator operatorData;
    public OperatorState(Entity operatorData, StateMachine macchine, string stateName) : base(operatorData, macchine, stateName)
    {
        this.operatorData = (Operator)operatorData;
    }

}
