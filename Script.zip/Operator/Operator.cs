using System;
using UnityEngine;

[Serializable]
public class Operator : Entity
{
    public event Action<PlayOperatorData> OperatorEnable;
    public event Action<PlayOperatorData> OperatorDisable;
    public event Action<Operator> OperatorDeploy;
    public event Action<Operator> OperatorDie;
    private PlayOperatorData _data;
    public PlayOperatorData data
    {
        get => _data;
        set
        {
            if (_data == null)
                _data = value;
            else
                Debug.LogError("Ŀ���Ա�ű�����Data�ļ�");
        }
    }

    [SerializeField]
    private PropertyGrowthSO operatorStatsGrowth;//��Ա�������Գɳ�����
    public PropertyGrowthSO statsGrowth { get => operatorStatsGrowth; }
    [Header("�������")]
    public float deployPanelDepth;//����δ����ʱ����Ա�������ĸ߶ȣ��������߶ȣ�

    public LayerMask whatIsGround;
    public LayerMask whatIsHighGround;

    public Operator_DragState dragState;
    public Operator_DeployState deployState;
    public Operator_IdleState idleState;
    public Operator_AttackState attackState;
    [HideInInspector]
    public UI_OperatorDeployOrientation deployOrientationUi; //��HeadItem������Ա����ʱ���롣

    public EnemyMoveType deployLocalType;//�з�����ʱʹ�ã��жϲ���λ���Ƿ�ɴ
    [Header("�赲���")]
    public int currentResist;//��ǰ�赲��
    public int byRegardTargetNumber;//��ǰ���ٵз�����
    [Header("�������")]
    public Terrain[] attackRanges;//������Χ
    protected override void Awake()
    {
        base.Awake();
        whatIsGround = LayerMask.GetMask("Ground");
        whatIsHighGround = LayerMask.GetMask("HighGround");
        
    }
    protected override void OnEnable()
    {
        base.OnEnable();
        OperatorEnable?.Invoke(data);
    }
    protected override void Start()
    {
        stats = data.configSo.stats;
        base.Start();
        canByCure = data.configSo.canByCure;
        machine.Initialize(dragState);
    }
    private void OnDisable()
    {
        machine.Initialize(dragState);
        OperatorDisable?.Invoke(data);
    }
    protected override void InitializeState()
    {
        base.InitializeState();
        dragState = new Operator_DragState(this, machine, "Default");
        deployState = new Operator_DeployState(this, machine, "Default");
        SpecialStateInitialzie();
    }

    protected virtual void SpecialStateInitialzie()
    {
        idleState = new Operator_IdleState(this, machine, "Idle");
        attackState = new Operator_AttackState(this, machine, "Idle");
    }

    public void OperatorDeployInitialize()
    {
        currentHealth = maxHealth;
        OperatorDeploy?.Invoke(this);
        PlayerDataManage.Instance.AddDeployOperator(this);
    }

    public void OperatorAttack(Terrain enemyTerrain)
    {
        if(machine.currentState is not Operator_AttackState)
            machine.CutState(attackState);
    }
    public override bool IsMayCure()
    {
        return currentHealth < maxHealth;
    }
    public override void TakeHealt(Stats_OffenseGroup offenseGroup)
    {
        base.TakeHealt(offenseGroup);
        Debug.Log("������"+data.id);
        damage.TakeHealt(offenseGroup,ref currentHealth);
    }
    public virtual void ByRegardTarget()
    {
        byRegardTargetNumber++;
    }
    protected virtual void OperatorReset()
    {
        foreach(Terrain terrain in attackRanges)
        {
            PlayerDataManage.Instance.attackRangeTerrains[terrain].Remove(this);
        }
        PlayerDataManage.Instance.deployOperators.Remove(this);
        PlayerDataManage.Instance.gridCanCureOperators.Remove(currentTerrain);
        byRegardTargetNumber = 0;
        currentTerrain.deployOperator = null;
    }
    public override void Die()
    {
        Debug.Log("Die");

        OperatorDie?.Invoke(this);
        base.Die();
    }
    public void Retreat()
    {
        foreach(Terrain terrain in attackRanges)
        {
            PlayerDataManage.Instance.attackRangeTerrains[terrain].Remove(this);
        }
        PlayerDataManage.Instance.deployOperators.Remove(this);
        PlayerDataManage.Instance.gridCanCureOperators.Remove(currentTerrain);
        byRegardTargetNumber = 0;
        currentTerrain.deployOperator = null;
        OperatorDie?.Invoke(this);
        gameObject.SetActive(false);
    }
}

