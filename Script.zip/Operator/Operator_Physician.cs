using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Operator_Physician : Operator
{
    protected override void SpecialStateInitialzie()
    {
        idleState = new Operator_PhysicianIdleState(this,machine,"Idle");
        attackState = new Operator_PhysicianAttackState(this,machine,"Idle");
    }
}
