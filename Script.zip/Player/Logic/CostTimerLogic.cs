using UnityEngine;

public class CostTimerLogic : MonoBehaviour
{
    private TimeManage timeManage;
    private PlayerDataManage playDataManage;
    private float presentTime;
    [SerializeField]
    private float costGainSpeed;

    private void Start()
    {
        timeManage = TimeManage.Instance;
        playDataManage = PlayerDataManage.Instance;
    }
    // Update is called once per frame
    void Update()
    {
        if (timeManage.Timer(costGainSpeed,ref presentTime))
        {
            playDataManage.AddCost(1);
        }
    }
    /// <summary>
    /// Cost��ȡ�ٶ�
    /// </summary>
    /// <returns></returns>
    public float GetCostGainSpeed()
    {
        return costGainSpeed;
    }
    /// <summary>
    /// ��ȡ��ǰʱ�����
    /// </summary>
    /// <returns></returns>
    public float GetCostPresentTime()
    {
        return presentTime;
    }
}
