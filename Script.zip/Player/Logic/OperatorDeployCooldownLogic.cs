using System;
using Unity.VisualScripting;
using UnityEngine;

public class OperatorDeployCooldownLogic : MonoBehaviour
{
    public event Action onCooldownOver;
    public bool cooldownOver{get;private set;}
    public event Action<float,int> updataTime; //floatΪ���룬intΪ��
    private UI_OperatorHeadItem head;

    private int cooldownTime;
    private float currentMsec = 1;
    private int currentTime;

    void Awake()
    {
        head = GetComponentInParent<UI_OperatorHeadItem>();
        head.deployCooldown += Enable;
        gameObject.SetActive(false);
    }
    void OnEnable()
    {
        cooldownOver = false;
        cooldownTime = head.operatorDeployTime;
        currentTime = cooldownTime;
    }
    void OnDisable()
    {
        cooldownOver = true;
    }
    // Update is called once per frame
    void Update()
    {
        if(currentTime <= 0)
        {
            onCooldownOver?.Invoke();
            gameObject.SetActive(false);
        }
        if(currentMsec > 0)
        {
            currentMsec -= Time.deltaTime;
        }
        else
        {
            currentMsec = 1;
            currentTime--;
        }
        
        updataTime?.Invoke(currentMsec,currentTime);
    }

    private void Enable()
    {
        gameObject.SetActive(true);
    }
}
