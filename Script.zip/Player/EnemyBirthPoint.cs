using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
public class EnemyBirthPoint : MonoBehaviour
{
    public static event Action<Wave[]> WaveStart;
    [SerializeField]
    [Header("���˳�����")]
    private Terrain[] birthPoints;
    [SerializeField]
    [Header("���˳�����ƫ����")]
    private Vector3 birthPointOffset;
    private System.Random _birtRandom;


    private bool _nextWave;
    private int _currentWave;
    [SerializeField]
    [Header("���˲���")]
       private Wave[] waves;

    protected void Awake()
    {
        _birtRandom = new System.Random();
        _nextWave = true;
    }

    // Update is called once per frame
    protected void Update()
    {
        if (_nextWave && _currentWave < waves.Length)
        {
            StartCoroutine(Wave());
        }
    }
/// <summary>
/// ����Э��
/// </summary>
/// <returns></returns>
    private IEnumerator Wave()
    {
        _nextWave = false;
        yield return new WaitForSeconds(waves[_currentWave].waveTime);
        StartCoroutine(EnemyBirth());
    }
    /// <summary>
    /// ���˳���Э��
    /// </summary>
    /// <returns></returns>
    private IEnumerator EnemyBirth()
    {
        TerrainManage tm = TerrainManage.Instance;
        Wave currentWave = waves[_currentWave];
        foreach(EnemyBirthInfo enemyBirt in currentWave.waveEnemys)
        {
            int birthPointIndex = _birtRandom.Next(0, birthPoints.Length - 1);
            Terrain birthPoint = birthPoints[birthPointIndex];

            enemyBirt.enemy.transform.position = tm.RangeToTerrainTopPosition(birthPoint.GetCurrentPosition()) + birthPointOffset;
            int birtNumber = enemyBirt.birtNumber;
            for(int i = 0; i < birtNumber; i++)
            {
                Enemy enemy = Instantiate(enemyBirt.enemy).GetComponent<Enemy>();
                Debug.Log($"�����: {SceneManager.GetActiveScene().name}, ���������ڳ���: {enemy.gameObject.scene.name}");
                // enemy.Initialize(birthPoint);
                if (enemyBirt.specialInterval)
                    yield return new WaitForSeconds(enemyBirt.specialTime);
                else
                    yield return new WaitForSeconds(currentWave.defaultIntervalTime);
            }
        }
        _currentWave++;
        _nextWave = true;
    }
}

[Serializable]
public class Wave
{
    [Header("���δ���ʱ��")]
    public float waveTime;//���δ���ʱ��

    [Header("���ε�����Ϣ")]
    public EnemyBirthInfo[] waveEnemys;//���ε�����Ϣ
    [Header("Ĭ�ϵ������ɼ��ʱ��")]
    public float defaultIntervalTime = 1f;//Ĭ�ϵ������ɼ��ʱ��
}
[Serializable]
public class EnemyBirthInfo
{
    [Header("�Ƿ����������")]
    public bool specialInterval;
    [Header("������ʱ��")]
    public float specialTime;
    [Header("����")]
       public GameObject enemy;
    [Header("������������")]
    public int birtNumber;
}